"""Offline artifact verification; no runtime or process observation."""
from pathlib import Path
import hashlib,json,struct,collections
BASE=Path('/workspace/scratch/first-minute/round-146/long-date-fixture-prep')
RUN=BASE/'run-new-01';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((RUN/'report.json').read_text());f=json.loads((BASE/'frozen.json').read_text())
checks=[]
def check(kind,path,expected):
    observed=sha(path);checks.append({'kind':kind,'path':str(path),'expected':expected,'observed':observed,'match':observed==expected})
for name,h in f['files'].items():check('prepared',BASE/name,h)
check('binding',BASE/'binding-new.json',r['bindingSHA256'])
for name,h in r['identityBefore']['sourcePins'].items():check('source',Path(r['source'])/name,h)
for path,h in r['identityBefore']['environmentPins'].items():check('environment',Path(path),h)
for side in ['httpBefore','httpAfter']:
    for row in r[side]['rows']:check(side,Path(r['source'])/row['name'],row['sha256'])
images=[];contexts=[];photo_inconsistencies=[]
fields=['selector','element','text','rect','display','visibility','opacity','effectiveOpacity','ancestorHidden','visibleProxy','fontSize','lineHeight','whiteSpace','animationName','transform','characters']
def projection(d):return {'date':d['date'],'elements':[{k:e.get(k) for k in fields} for e in d['elements']]}
for c in r['contexts']:
    w,h=c['viewport'].values();vp=f'{w}x{h}';pairs=[(vp+'-initial.png',c['initial'],c['initialAfterPhoto'])]
    for m in c['modes']:
        check('rows',RUN/m['file'],m['sha256']);pairs.append((vp+'-'+m['mode']+'-max.png',m['beforePhoto'],m['afterPhoto']))
    pairmap={name:(a,b) for name,a,b in pairs}
    for p in c['photos']:
        path=RUN/p['name'];check('png',path,p['sha256']);data=path.read_bytes();dims=struct.unpack('>II',data[16:24])
        before,after=pairmap[p['name']];same=projection(before)==projection(after)
        if not same:photo_inconsistencies.append(p['name'])
        images.append({'file':p['name'],'sha256':sha(path),'dimensions':dims,'dimensionsMatchViewport':dims==(w,h),'beforeAfterRecordedGeometrySame':same,'date':before['date'],'viewedOriginal':True,'visualFinding':'Both round arrows visible beside date; date, title, both choice texts, paddy word, home and sound icon remain separate in this original PNG. Maximum-date horizontal gap is narrow; numeric glyph boxes are the quantitative evidence.'})
    restore=[m[k] for m in c['modes'] for k in ['restoration','photoRestoration']]
    events=c['inputObservation']['events'];oc=c['original'];ac=c['afterRestoration']
    contexts.append({'viewport':c['viewport'],'restorations':[{'matches':x['dateText']==oc['dateText'] and x['cardClass']==oc['cardClass'] and x['matches'],'attempted':x['attempted']} for x in restore],'finalRestoration':c['finalRestoration'],'savedBytesEqual':oc['save']==ac['save'],'originalAfterDateClassEqual':oc['dateText']==ac['dateText'] and oc['cardClass']==ac['cardClass'],'trustedInputs':sum(e['trusted'] for e in events),'untrustedInputs':events,'droppedInputs':c['inputObservation']['dropped'],'contextClosed':c['contextClosed'],'cpuReset':c['cpuReset'],'initialThree':c['initial']['three'],'initialSound':c['initial']['sound']})
closure=json.loads((RUN/'root-closure.json').read_text());clar=json.loads((RUN/'root-closure-clarification.json').read_text())
summary={'reportSHA256':sha(RUN/'report.json'),'checks':checks,'allHashChecksMatch':all(x['match'] for x in checks),'hashCheckCount':len(checks),'sourceEnvironmentBeforeAfterEqual':r['identityBefore']==r['identityAfter'],'images':images,'pngCount':len(images),'uniquePNGCount':len({x['sha256'] for x in images}),'originalPNGsViewed':15,'originalPNGsUnseen':0,'photoGeometryDiscrepancies':photo_inconsistencies,'contexts':contexts,'consoleCounts':dict(collections.Counter(e['type'] for c in r['contexts'] for e in c['console'])),'consoleErrors':[e for c in r['contexts'] for e in c['console'] if e['type']=='error'],'pageErrors':sum(len(c['pageErrors']) for c in r['contexts']),'requestFailures':sum(len(c['requestFailures']) for c in r['contexts']),'httpErrors':sum(len(c['httpErrors']) for c in r['contexts']),'blocked':sum(len(c['blocked']) for c in r['contexts']),'actualExit':r['exitCode'],'browserClosed':r['browserClosed'],'historicalLiveBrowserCount':len(closure['gateAfter']['liveBrowsers']),'rootClosureSHA256':sha(RUN/'root-closure.json'),'rootClarificationSHA256':sha(RUN/'root-closure-clarification.json'),'clarificationPreservesOriginal':clar['originalClosureSHA256']==sha(RUN/'root-closure.json'),'rootExecutionGateSHA256':sha(BASE/'root-execution-gate.json'),'fixtureFrozenSHA256':sha(BASE/'frozen.json'),'bindingClarification':'Closure gateAfter is the repeat runner shared source/env/HTTP/server/live0 gate. Its binding/prepared8/parse3 are not fixture binding or fixture prepared evidence. Fixture own entry validates frozen prepared7; binding-new and runtime identity/http are verified above; separate root-execution-gate contains fixture parse3. The parent message 569ec5 was not the closure file SHA.'}
(OUT/'metadata-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['checks','images','contexts']},ensure_ascii=False,indent=2))
