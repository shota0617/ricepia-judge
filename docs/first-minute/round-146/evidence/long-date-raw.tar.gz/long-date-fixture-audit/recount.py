"""Offline recount of saved JSON only; never invokes product/browser/Node."""
from pathlib import Path
import hashlib, json, math, struct

SRC = Path('/workspace/scratch/first-minute/round-146/long-date-fixture-prep/run-new-01')
OUT = Path(__file__).resolve().parent
report = json.loads((SRC/'report.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
issues = []
def check(ok, where):
    if not ok: issues.append(where)
def close(a,b):
    return a == b if a is None or b is None else abs(a-b) < 1e-9
def relation(a,b):
    horizontal_separation = max(b['left']-a['right'], a['left']-b['right'])
    vertical_separation = max(b['top']-a['bottom'], a['top']-b['bottom'])
    overlap_width = max(0, min(a['right'],b['right'])-max(a['left'],b['left']))
    overlap_height = max(0, min(a['bottom'],b['bottom'])-max(a['top'],b['top']))
    if horizontal_separation >= 0 or vertical_separation >= 0:
        distance = math.hypot(max(0,horizontal_separation),max(0,vertical_separation))
    else:
        distance = max(horizontal_separation,vertical_separation)
    return overlap_width*overlap_height, distance
def inside(r,w,h):
    return r is not None and r['left']>=0 and r['top']>=0 and r['right']<=w and r['bottom']<=h
text_selectors={'#swTitle','#swEdge .eL .eLb','#swEdge .eR .eLb','#swPdWord'}
expected_selectors=text_selectors|{'#swPaddy','#swHome','#swSnd','#swHand .hdFinger'}
expected_dates={(m,d) for m in range(1,13) for d in range(1,32)}
counts={'rows':0,'valid':0,'unknown':0,'dateIntersectionRows':0,'otherIntersectionRows':0,'otherUnavailableRows':0,'datePairs':0,'otherPairs':0}
tables=[]
global_other={s:None for s in sorted(expected_selectors)}
date_min=None
all_min_dates=set()
for p in sorted(SRC.glob('*-rows.json')):
    viewport, mode = p.name.removesuffix('-rows.json').split('-',1)
    width,height=map(int,viewport.split('x'))
    table=json.loads(p.read_text()); rows=table['rows']
    check(len(rows)==372, p.name+': count')
    check({(r['month'],r['day']) for r in rows}==expected_dates,p.name+': dates')
    check(table['restoration']['matches'] is True,p.name+': restore')
    stats={'file':p.name,'sha256':sha(p),'rows':len(rows),'valid':0,'unknown':0,'dateIntersectionRows':0,'otherIntersectionRows':0,'otherUnavailableRows':0,'minDateSignedGap':None,'maxDateWidth':None,'widestDates':[], 'recordedTableRestoration':table['restoration'],'dateCSSFont':table['dateCSSFont']}
    for idx,row in enumerate(rows):
        loc=f'{p.name}:{idx+1}'
        check(row['mode']==mode and table['mode']==mode,loc+': mode')
        check(row['text']==f"{row['month']}月{row['day']}日",loc+': text')
        chars=row['dateCharacters']; glyphs=[q for c in chars for q in c['rects']]
        check(''.join(c['char'] for c in chars)==row['text'],loc+': characters')
        ranges=bool(chars) and len(chars)==len(row['text']) and all(c['rects'] and all(q['width']>0 and q['height']>0 for q in c['rects']) for c in chars)
        arrows=row['arrows']
        check([a['selector'] for a in arrows]==['#swGuide .gdL','#swGuide .gdR'],loc+': arrows')
        a_inside=all(inside(a['rect'],width,height) for a in arrows)
        d_inside=bool(glyphs) and all(inside(q,width,height) for q in glyphs)
        valid=bool(row['dateVisible'] and row['fontReady'] and ranges and a_inside and d_inside and all(a['visible'] and a['rect'] for a in arrows))
        for key,value in [('rangesPresent',ranges),('arrowsFullyInside',a_inside),('dateFullyInside',d_inside),('valid',valid)]:check(row[key]==value,loc+': '+key)
        counts['rows']+=1;counts['valid' if valid else 'unknown']+=1;stats['valid' if valid else 'unknown']+=1
        date_width=max(q['right'] for q in glyphs)-min(q['left'] for q in glyphs)
        check(close(date_width,row['dateWidth']),loc+': width')
        if stats['maxDateWidth'] is None or date_width>stats['maxDateWidth']:
            stats['maxDateWidth']=date_width;stats['widestDates']=[row['text']]
        elif date_width==stats['maxDateWidth']:stats['widestDates'].append(row['text'])
        gaps=[];overlaps=[]
        for a in arrows:
            if a['rect']:
                check(a['rect']['width']==70 and a['rect']['height']==54 and a['fontSize']=='40px' and a['animationName']=='none',loc+': unchanged circle')
                for ci,c in enumerate(chars):
                    for q in c['rects']:
                        area,gap=relation(a['rect'],q);gaps.append(gap);counts['datePairs']+=1
                        if area>0:overlaps.append({'arrow':a['selector'],'index':ci,'char':c['char'],'area':area,'signedGap':gap})
        check(overlaps==row['dateOverlaps'],loc+': date overlaps')
        minimum=min(gaps) if valid and gaps else None
        check(close(minimum,row['minDateSignedGap']),loc+': date gap')
        if minimum is not None:
            if stats['minDateSignedGap'] is None or minimum<stats['minDateSignedGap']:stats['minDateSignedGap']=minimum
            if date_min is None or minimum<date_min:date_min=minimum;all_min_dates={row['text']}
            elif minimum==date_min:all_min_dates.add(row['text'])
        if overlaps:counts['dateIntersectionRows']+=1;stats['dateIntersectionRows']+=1
        check({r['selector'] for r in row['otherRelations']}==expected_selectors and len(row['otherRelations'])==8,loc+': target set')
        other_overlap=False;other_unavailable=False
        for target in row['otherRelations']:
            selector=target['selector'];boxes=target['rangeRects'] if selector in text_selectors else ([target['rect']] if target['rect'] else [])
            available=bool(target['visible'] and boxes)
            check(available==target['measurementAvailable'],loc+': available '+selector)
            other_unavailable|=not available
            ogaps=[];ointersections=[]
            if target['visible']:
                for a in arrows:
                    if a['visible'] and a['rect']:
                        for q in boxes:
                            area,gap=relation(a['rect'],q);ogaps.append(gap);counts['otherPairs']+=1
                            if area>0:ointersections.append({'arrow':a['selector'],'area':area,'signedGap':gap})
            check(ointersections==target['overlap'],loc+': other overlaps '+selector)
            omin=min(ogaps) if ogaps else None
            check(close(omin,target['minSignedGap']),loc+': other gap '+selector)
            if omin is not None and (global_other[selector] is None or omin<global_other[selector]):global_other[selector]=omin
            other_overlap|=bool(ointersections)
        if other_overlap:counts['otherIntersectionRows']+=1;stats['otherIntersectionRows']+=1
        if other_unavailable:counts['otherUnavailableRows']+=1;stats['otherUnavailableRows']+=1
    tables.append(stats)
photos=[]
for c in report['contexts']:
    for photo in c['photos']:
        photos.append(photo)
result={'scope':'Independent offline calculation from all saved rectangle rows; no browser, Node, product, input, state or image changes. Visibility/font observations are recorded data, not newly observed.', 'sourceReport':str(SRC/'report.json'),'sourceReportSHA256':sha(SRC/'report.json'),'counts':counts,'globalMinDateSignedGap':date_min,'datesAtGlobalMinimum':sorted(all_min_dates),'otherMinimumSignedGaps':global_other,'tables':tables,'discrepancies':issues,'photosRecordedCount':len(photos),'rawRowsBytes':sum(p.stat().st_size for p in SRC.glob('*-rows.json'))}
(OUT/'geometry-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['tables','datesAtGlobalMinimum']},ensure_ascii=False,indent=2))
print('table_summary',json.dumps([{k:s[k] for k in ['file','rows','valid','minDateSignedGap','maxDateWidth']} for s in tables],ensure_ascii=False))
