# R146 長日付レイアウトfixture — root実行待ち

未実行。通常primary/自然10回とは別母数で、DOM文字幅を調べる。製品・既存テストを変更しない。rootが適用候補のHTML SHAを別bindingへ入れるまで起動不可。

新contextを順に844×390、568×320、564×440。mobile/touch/DPR1/CPU1、正規reduce、実時計・実音API・実描画ライブラリ、localhost:8000のみ許可。rootのtop33候補はmin-width564なので3画面とも対象。外部取得は遮断して記録する。音の実聴、実機GPU、実保存再開を証明する実験ではない。

各contextはDCL→実fonts.ready→実3秒待ち→自然demoOn/静止矢印/日付・札の可視を確認する。初期実日付・class・保存値を読み、受動診断と初期原PNGを残す。強制表示や手本APIを呼ばない。初期音ctx/3D activeは合格条件にしない。

次に **日付textContentとcardのgold/festクラスだけ** を明示fixtureとして一時変更する。normal/gold/fest/goldfestの各モードで、1月1日から12月31日まで「12か月×31日」の372文字列を読む。2月31日など非実在日付も字幅stressであり、ゲームの暦や進行として扱わない。1画面1488件、3画面4464件。fresh元classにgold/festが既にある場合は、取り除いてnormalを作らずUNKNOWNとして停止する。

各行はdateの全Unicode文字Rangeと円rect、交差、最小signed gap、font-ready/可視/画面内を保存する。正のgapは矩形間距離、0は接触、負は分離に必要な最小軸移動量。各円と題/左右札/状態文の文字Range、小田んぼ/家/音/停止指のbox交差も記録。非表示やRange欠測のgapはnullで、0交差の成功に畳まない。円はpointer-events:noneなのでhitstackだけで可視性を判定しない。

372件は同じpage.evaluate内で同期測定し、各text変更後のlayout readを使う。全372枚が物理paintされたとは言わず、これによる観測負荷を製品性能として報告しない。各モードで最大幅の最初の文字列をもう一度明示設定し、診断→原PNG→診断を取る。4モード×3画面の最大幅PNG12枚＋初期3枚＝予定15枚。写真前後と同一フレームとは言わない。

各372件のtry/finally、最大幅写真のtry/finally、context外枠finallyで、元dateTextとclass属性を厳密復元する。fixture専用の観測markerに復元元とactiveを記録し、fixtureが開始されていない・既に復元済みなら外枠は読取比較だけでDOMを上書きしない。文字列の完全一致を保存し、保存値は前後readで比較する。差が出ても保存を修復しない。fixtureがゲームstate/seed/save/時計/音/renderを置換する処理は無い。写真/診断失敗と復元失敗は別々に記録し、二重例外で先行原因を消さない。自然timerが走るため無入力30秒カード等が出れば、その可視欠測/保存差はそのまま残る。次contextへ進むのは復元・CPU reset・context閉鎖まで確認した場合だけ。

source7/env8はpilot原manifestと同byte。oldは元HTML `1131aca2…` に固定、newのみrootがレビュー済みHTML SHAを指定する。source他6/env8は変更不可。HTTP5を前後全件照合。prepared SHAを起動時に照合し、新規direct-child `run-*`以外や既存出力を拒否する。primary/pilot/自然反復のファイルはコピーも上書きもしない。

rootのみ：3本をparseし、現在HEAD・適用HTML・serverのWT146束縛・他owned browser0を確認。`binding-template.json`から **別ファイル** `binding-new.json` を作り、variant/new、htmlSHA256、rootGateReceipt、ready:true/pendingRootGate:falseを入れる。old比較なら同様にbinding-old.jsonと元SHA。template自体は固定・ready:false。

```sh
R146_LONGDATE_ROOT=1 R146_ROOT_HEAD=6334d3103bbfa20f8b92e744b369be2183af1abe timeout --signal=TERM --kill-after=5s 240s /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/scratch/first-minute/round-146/long-date-fixture-prep/run.cjs binding-new.json run-new-01
```

browser開始後160秒watchdog、個別evaluate/写真/closeにもboundがある。timeout後に元DOMへ戻ったことは推定しない。復元不明・閉鎖不明なら次contextへ進まず、最後にbrowserを閉じる。外側の強制終了はfinally/子孫閉鎖を保証しないため、rootが残存process0を別確認し、不明なら次実行しない。

consoleは全種類、page/request/HTTP/外部遮断を全記録し、favicon404を除外せず終了コード1へ反映する。`complete`（全件記録・復元・閉鎖・束縛）、`allLayoutTargetsMeasured`（欠測なし）、`allRecordedIntersectionsClear`（記録上の交差なし）、実exitを分ける。幾何clearは原PNGや自然再現の合格、自然保存再開、人の理解/離脱改善を意味しない。

diagnose.cjsはpilot原版から小田んぼ/状態文の2selectorを加えた受動診断。run/measureはこの明示fixture専用。準備時Node/parse/browser/HTTP/Git/テスト実行0。
