'use strict';
// Explicit DOM layout fixture: no input, product API, storage or clock mutation.
module.exports = function measure({mode, original}) {
  const date=document.querySelector('#swBigDate'),card=document.querySelector('#swCard');
  const rect=r=>({left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height});
  const visible=e=>{if(!e)return false;let opacity=1;for(let n=e;n;n=n.parentElement){const c=getComputedStyle(n);opacity*=Number(c.opacity);if(c.display==='none'||c.visibility==='hidden'||c.visibility==='collapse')return false;}const r=e.getBoundingClientRect();return opacity>.01&&r.width>0&&r.height>0;};
  function characters(e){const a=[],w=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let n;(n=w.nextNode());){for(let i=0;i<n.length;){const char=String.fromCodePoint(n.data.codePointAt(i)),r=document.createRange();r.setStart(n,i);i+=char.length;r.setEnd(n,i);a.push({char,rects:Array.from(r.getClientRects(),rect)});}}return a;}
  function relation(a,b){const dx=Math.max(b.left-a.right,a.left-b.right),dy=Math.max(b.top-a.bottom,a.top-b.bottom),w=Math.min(a.right,b.right)-Math.max(a.left,b.left),h=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);return {area:Math.max(0,w)*Math.max(0,h),signedGap:dx>=0||dy>=0?Math.hypot(Math.max(0,dx),Math.max(0,dy)):Math.max(dx,dy)};}
  const arrows=['#swGuide .gdL','#swGuide .gdR'],others=['#swTitle','#swEdge .eL .eLb','#swEdge .eR .eLb','#swPaddy','#swPdWord','#swHome','#swSnd','#swHand .hdFinger'];
  const rows=[],started=performance.now();let restoration=null,measurementError=null;
  if(!date||!card)throw Error('Missing original date/card');
  if(date.textContent!==original.dateText||card.getAttribute('class')!==original.cardClass)throw Error('Fixture starts from changed original DOM');
  if(/(?:^|\s)(?:gold|fest)(?:\s|$)/.test(original.cardClass||''))throw Error('Fresh original already gold/fest: normal/additive fixture unavailable');
  if(window.__r146LongDateFixture?.active)throw Error('Previous fixture still active');
  window.__r146LongDateFixture={active:true,original:{dateText:original.dateText,cardClass:original.cardClass},phase:'table-'+mode};
  try{
    card.setAttribute('class',(original.cardClass||'')+(mode==='normal'?'':' '+mode.replace('goldfest','gold fest')));
    for(let month=1;month<=12;month++)for(let day=1;day<=31;day++){
      const text=month+'月'+day+'日';date.textContent=text;
      const a=arrows.map(selector=>{const e=document.querySelector(selector),s=e?getComputedStyle(e):null;return {selector,visible:visible(e),rect:e?rect(e.getBoundingClientRect()):null,fontSize:s?.fontSize,animationName:s?.animationName};});
      const chars=characters(date),glyphs=chars.flatMap(x=>x.rects),rangesPresent=chars.length===Array.from(text).length&&chars.every(x=>x.rects.length&&x.rects.every(r=>r.width>0&&r.height>0));
      const inside=r=>!!r&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;
      const dateVisible=visible(date),fontReady=document.fonts.status==='loaded',arrowsFullyInside=a.every(x=>inside(x.rect)),dateFullyInside=glyphs.length>0&&glyphs.every(inside),valid=dateVisible&&fontReady&&rangesPresent&&arrowsFullyInside&&dateFullyInside&&a.every(x=>x.visible&&x.rect);
      const dateRelations=[],dateOverlaps=[];
      for(const ar of a)if(ar.rect)for(const [index,c]of chars.entries())for(const r of c.rects){const rel=relation(ar.rect,r);dateRelations.push(rel.signedGap);if(rel.area>0)dateOverlaps.push({arrow:ar.selector,index,char:c.char,...rel});}
      const otherRelations=others.map(selector=>{const e=document.querySelector(selector),isVisible=visible(e),r=e?rect(e.getBoundingClientRect()):null,isText=selector==='#swTitle'||selector.endsWith('.eLb')||selector==='#swPdWord',cs=isVisible&&isText?characters(e):[],boxes=isText?cs.flatMap(c=>c.rects):(r?[r]:[]);let overlap=[],gaps=[];if(isVisible)for(const ar of a)if(ar.visible&&ar.rect)for(const b of boxes){const rel=relation(ar.rect,b);gaps.push(rel.signedGap);if(rel.area>0)overlap.push({arrow:ar.selector,...rel});}const x=r?(r.left+r.right)/2:null,y=r?(r.top+r.bottom)/2:null,hit=r&&x>=0&&x<innerWidth&&y>=0&&y<innerHeight?document.elementFromPoint(x,y):null;return {selector,text:e?.textContent??null,visible:isVisible,rect:r,rangeRects:cs.flatMap(c=>c.rects),measurementAvailable:isVisible&&boxes.length>0,minSignedGap:gaps.length?Math.min(...gaps):null,overlap,centerOwned:!!e&&!!hit&&(hit===e||e.contains(hit))};});
      const width=glyphs.length?Math.max(...glyphs.map(r=>r.right))-Math.min(...glyphs.map(r=>r.left)):null;
      rows.push({month,day,text,mode,at:performance.now(),dateVisible,fontReady,rangesPresent,arrowsFullyInside,dateFullyInside,valid,dateWidth:width,dateCharacters:chars,arrows:a,dateOverlaps,minDateSignedGap:valid&&dateRelations.length?Math.min(...dateRelations):null,otherRelations});
    }
  }catch(e){measurementError=String(e.stack||e);throw e;}finally{
    try{
      date.textContent=original.dateText;if(original.cardClass===null)card.removeAttribute('class');else card.setAttribute('class',original.cardClass);
      restoration={attempted:true,dateText:date.textContent,cardClass:card.getAttribute('class'),matches:date.textContent===original.dateText&&card.getAttribute('class')===original.cardClass};
      if(!restoration.matches)throw Error('Exact DOM restoration failed');
      window.__r146LongDateFixture.active=false;
    }catch(e){throw Error('Measurement error: '+(measurementError||'none')+'; restoration error: '+String(e.stack||e));}
  }
  const style=getComputedStyle(date);
  return {mode,started,completed:performance.now(),rows,restoration,dateCSSFont:{family:style.fontFamily,size:style.fontSize,weight:style.fontWeight,lineHeight:style.lineHeight},geometryOnly:true,nonexistentDatesIncluded:true};
};
