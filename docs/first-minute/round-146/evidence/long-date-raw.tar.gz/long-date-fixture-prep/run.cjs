'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),root=__dirname;
const source='/workspace/ricepia-firstminute-round146',origin='http://localhost:8000',head='6334d3103bbfa20f8b92e744b369be2183af1abe';
if(process.env.R146_LONGDATE_ROOT!=='1'||process.env.R146_ROOT_HEAD!==head)throw Error('Root parse/source/server/browser gate required before imports or output');
const [bindingName,outName]=process.argv.slice(2);
if(!/^binding-(old|new)\.json$/.test(bindingName||'')||!/^run-[a-z0-9-]+$/.test(outName||''))throw Error('Usage: run.cjs binding-old|new.json new-run-child');
const output=path.join(root,outName);if(fs.existsSync(output))throw Error('Output exists; immutable attempts only');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),stamp=()=>({epoch:Date.now(),monotonic:Number(process.hrtime.bigint())/1e6});
const bindingBytes=fs.readFileSync(path.join(root,bindingName)),binding=JSON.parse(bindingBytes);
if(binding.ready!==true||binding.pendingRootGate!==false||binding.sourceRoot!==source||binding.head!==head||!/^([a-f0-9]{64})$/.test(binding.htmlSHA256||'')||!binding.rootGateReceipt||binding.variant!==bindingName.slice(8,-5))throw Error('Reviewed exact source binding is not ready');
const frozen=JSON.parse(fs.readFileSync(path.join(root,'frozen.json')));
for(const [name,sha]of Object.entries(frozen.files))if(hash(fs.readFileSync(path.join(root,name)))!==sha)throw Error('Prepared bytes changed: '+name);
const sourceManifest=JSON.parse(fs.readFileSync(path.join(root,'source-manifest.json'))),env=JSON.parse(fs.readFileSync(path.join(root,'environment-manifest.json'))),expected={...sourceManifest.source};
if(binding.variant==='old'&&binding.htmlSHA256!==expected['kome365/index.html'])throw Error('Old HTML must be original pinned bytes');
if(binding.variant==='new'&&binding.htmlSHA256===expected['kome365/index.html'])throw Error('New must be separately reviewed candidate bytes');
expected['kome365/index.html']=binding.htmlSHA256;
const diagnose=require('./diagnose.cjs'),measure=require('./measure.cjs');
const bounded=(promise,ms,label)=>{let t;return Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]).finally(()=>clearTimeout(t));};
function identity(){const sourcePins={},environmentPins={};for(const [name,sha]of Object.entries(expected)){sourcePins[name]=hash(fs.readFileSync(path.join(source,name)));if(sourcePins[name]!==sha)throw Error('Source mismatch '+name);}for(const [name,sha]of Object.entries(env.hashes)){environmentPins[name]=hash(fs.readFileSync(name));if(environmentPins[name]!==sha)throw Error('Environment mismatch '+name);}return {sourcePins,environmentPins};}
async function httpGate(){const settled=await Promise.allSettled(sourceManifest.httpFiles.map(async name=>{const r=await fetch(origin+'/'+name,{redirect:'error',signal:AbortSignal.timeout(10000)}),sha256=hash(Buffer.from(await r.arrayBuffer()));return {name,status:r.status,sha256,matched:r.status===200&&sha256===expected[name]};}));const rows=settled.map((x,i)=>x.status==='fulfilled'?x.value:{name:sourceManifest.httpFiles[i],error:String(x.reason),matched:false});return {rows,matched:rows.every(r=>r.matched)};}
const readOriginal=()=>{const d=document.querySelector('#swBigDate'),c=document.querySelector('#swCard');return {dateText:d?.textContent??null,cardClass:c?.getAttribute('class')??null,save:Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('kome365_')).sort().map(k=>[k,localStorage.getItem(k)]))};};
const restore=original=>{const d=document.querySelector('#swBigDate'),c=document.querySelector('#swCard'),f=window.__r146LongDateFixture;if(!d||!c)throw Error('DOM missing at restoration');const attempted=f?.active===true;if(attempted){if(f.original.dateText!==original.dateText||f.original.cardClass!==original.cardClass)throw Error('Fixture restoration owner mismatch');d.textContent=original.dateText;if(original.cardClass===null)c.removeAttribute('class');else c.setAttribute('class',original.cardClass);}const matches=d.textContent===original.dateText&&c.getAttribute('class')===original.cardClass;if(attempted&&matches)f.active=false;return {attempted,dateText:d.textContent,cardClass:c.getAttribute('class'),matches};};
(async()=>{
 fs.mkdirSync(output);let browser,watchdog;
 const result={protocol:'R146 explicit long-date DOM layout fixture; not natural play or saved-state replay',source,head,binding,bindingSHA256:hash(bindingBytes),started:stamp(),contexts:[],errors:[],browserClosed:false,expectedCases:3*4*372,status:'INCOMPLETE'};
 const save=()=>fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(result,null,2)+'\n');
 const issue=(stage,e)=>{result.errors.push({stage,at:stamp(),message:String(e.stack||e)});process.exitCode=1;save();};save();
 try{
  result.identityBefore=identity();result.httpBefore=await httpGate();if(!result.httpBefore.matched)throw Error('HTTP source mismatch');
  const {chromium}=require('module').createRequire('/workspace/ricepia-judge/tools/playtest.js')('playwright');
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,ignoreDefaultArgs:['--mute-audio'],args:['--no-sandbox','--disable-background-networking','--disable-component-update','--disable-sync','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost']});
  watchdog=setTimeout(()=>{result.timedOut=true;issue('watchdog',Error('160s browser watchdog'));browser.close().catch(e=>issue('watchdog-close',e));},160000);
  const bc=await browser.newBrowserCDPSession();try{result.actualArguments=(await bounded(bc.send('Browser.getBrowserCommandLine'),5000,'arguments')).arguments;result.actualUnmuted=!result.actualArguments.some(a=>/^--mute-audio(?:=|$)/.test(a));if(!result.actualUnmuted)throw Error('Muted launch');}finally{await bc.detach();}
  for(const [width,height]of [[844,390],[568,320],[564,440]]){
   if(result.timedOut)throw Error('Watchdog terminated before next context');
   const c={viewport:{width,height},reducedMotion:'reduce',started:stamp(),modes:[],console:[],pageErrors:[],requestFailures:[],httpErrors:[],blocked:[],photos:[],contextClosed:false,status:'INCOMPLETE'};result.contexts.push(c);
   let context,page,cdp,original,failed=false;const prefix=width+'x'+height;
   async function photo(name){const row={name,requested:stamp()};c.photos.push(row);try{await bounded(page.screenshot({path:path.join(output,name),timeout:10000}),11000,'photo');row.completed=stamp();row.sha256=hash(fs.readFileSync(path.join(output,name)));return row;}catch(e){row.error={at:stamp(),message:String(e.stack||e)};save();throw e;}}
   try{
    context=await browser.newContext({viewport:c.viewport,isMobile:true,hasTouch:true,deviceScaleFactor:1,serviceWorkers:'block',reducedMotion:'reduce'});
    await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)&&u.port==='8000')return route.continue();c.blocked.push({at:stamp(),url:u.href});return route.abort('blockedbyclient');});
    await context.addInitScript(()=>{window.__r146LongDateInputs=[];window.__r146LongDateInputDropped=0;for(const type of ['pointerdown','pointerup','pointercancel','click','keydown','keyup'])addEventListener(type,e=>{if(window.__r146LongDateInputs.length<1000)window.__r146LongDateInputs.push({type,at:performance.now(),trusted:e.isTrusted,target:e.target?.id??null});else window.__r146LongDateInputDropped++;},{capture:true,passive:true});});
    page=await context.newPage();page.setDefaultTimeout(10000);
    page.on('console',m=>c.console.push({at:stamp(),type:m.type(),message:m.text(),location:m.location()}));page.on('pageerror',e=>c.pageErrors.push({at:stamp(),message:String(e.stack||e)}));page.on('requestfailed',q=>c.requestFailures.push({at:stamp(),url:q.url(),failure:q.failure()}));page.on('response',r=>{if(r.status()>=400)c.httpErrors.push({at:stamp(),url:r.url(),status:r.status()});});
    cdp=await context.newCDPSession(page);await bounded(cdp.send('Emulation.setCPUThrottlingRate',{rate:1}),5000,'CPU1');c.cpu1=true;
    c.navigation={requested:stamp(),url:origin+'/kome365/index.html'};const response=await page.goto(c.navigation.url,{waitUntil:'domcontentloaded',timeout:20000});c.navigation.completed=stamp();if(response?.status()!==200||page.url()!==c.navigation.url)throw Error('Navigation mismatch');
    c.fonts=await bounded(page.evaluate(()=>document.fonts.ready.then(()=>({status:document.fonts.status,at:performance.now()}))),8000,'fonts ready');
    c.initialWait={started:stamp(),requestedMs:3000};await new Promise(resolve=>setTimeout(resolve,3000));c.initialWait.completed=stamp();
    await page.waitForFunction(()=>matchMedia('(prefers-reduced-motion: reduce)').matches&&document.fonts.status==='loaded'&&document.querySelector('#swWrap')?.classList.contains('demoOn')&&!!document.querySelector('#swBigDate')?.textContent&&['.gdL','.gdR'].every(s=>{const e=document.querySelector('#swGuide '+s);if(!e)return false;const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).animationName==='none';}),{},{timeout:5000});
    original=await bounded(page.evaluate(readOriginal),5000,'original');c.original=original;c.initial=await bounded(page.evaluate(diagnose),10000,'initial diagnostic');
    const required=['#swCard','#swGuide .gdL','#swGuide .gdR','#swBigDate','#swTitle','#swEdge .eL .eLb','#swEdge .eR .eLb'];if(!required.every(s=>c.initial.elements.find(e=>e.selector===s)?.visibleProxy))throw Error('Initial visible fixture prerequisites absent');
    await photo(prefix+'-initial.png');c.initialAfterPhoto=await bounded(page.evaluate(diagnose),10000,'initial after photo');
    for(const mode of ['normal','gold','fest','goldfest']){
     const m={mode,requested:stamp()};c.modes.push(m);const data=await bounded(page.evaluate(measure,{mode,original}),25000,'372-date '+mode);m.completed=stamp();m.file=prefix+'-'+mode+'-rows.json';fs.writeFileSync(path.join(output,m.file),JSON.stringify(data)+'\n');m.sha256=hash(fs.readFileSync(path.join(output,m.file)));m.rows=data.rows.length;m.restoration=data.restoration;
     const valid=data.rows.filter(r=>r.valid);m.validRows=valid.length;m.unknownRows=data.rows.length-valid.length;m.dateOverlapRows=valid.filter(r=>r.dateOverlaps.length).length;m.minDateSignedGap=valid.length?Math.min(...valid.map(r=>r.minDateSignedGap)):null;
     m.otherUnknownRows=data.rows.filter(r=>r.otherRelations.some(x=>!x.measurementAvailable)).length;m.otherOverlapRows=data.rows.filter(r=>r.otherRelations.some(x=>x.measurementAvailable&&x.overlap.length)).length;
     if(data.rows.length!==372||new Set(data.rows.map(r=>r.text)).size!==372||!data.restoration.matches)throw Error('Fixture coverage/restoration incomplete');
     const widest=data.rows.filter(r=>r.rangesPresent&&Number.isFinite(r.dateWidth)).reduce((best,r)=>!best||r.dateWidth>best.dateWidth?r:best,null);if(!widest)throw Error('No measurable date width');m.widest={text:widest.text,width:widest.dateWidth,minDateSignedGap:widest.minDateSignedGap,valid:widest.valid};
     try{
      await bounded(page.evaluate(({mode,original,text})=>{const d=document.querySelector('#swBigDate'),c=document.querySelector('#swCard');if(!d||!c||d.textContent!==original.dateText||c.getAttribute('class')!==original.cardClass||window.__r146LongDateFixture?.active)throw Error('Max-photo fixture original mismatch');window.__r146LongDateFixture={active:true,original:{dateText:original.dateText,cardClass:original.cardClass},phase:'photo-'+mode};d.textContent=text;c.setAttribute('class',(original.cardClass||'')+(mode==='normal'?'':' '+mode.replace('goldfest','gold fest')));},{mode,original,text:widest.text}),5000,'max-date fixture');
      m.beforePhoto=await bounded(page.evaluate(diagnose),10000,'max before');await photo(prefix+'-'+mode+'-max.png');m.afterPhoto=await bounded(page.evaluate(diagnose),10000,'max after');
     }catch(e){m.photoError={at:stamp(),message:String(e.stack||e)};save();throw e;}finally{try{m.photoRestoration=await bounded(page.evaluate(restore,original),5000,'photo restoration');if(!m.photoRestoration.matches)throw Error('Photo exact restoration failed');}catch(e){m.photoRestoreError={at:stamp(),message:String(e.stack||e)};save();throw e;}}
     save();
    }
    c.status='COMPLETE_GEOMETRY_FIXTURE_NOT_GAMEPLAY';
   }catch(e){failed=true;c.error=String(e.stack||e);issue(prefix,e);}
   finally{
    if(page&&original){try{c.finalRestoration=await bounded(page.evaluate(restore,original),5000,'final restoration');c.afterRestoration=await bounded(page.evaluate(readOriginal),5000,'restored snapshot');c.savedBytesUnchanged=JSON.stringify(c.afterRestoration.save)===JSON.stringify(original.save);if(!c.finalRestoration.matches||!c.savedBytesUnchanged)throw Error('Restoration/save differs; never rewrite save to repair');}catch(e){failed=true;issue(prefix+' restore',e);}}
    if(page){try{c.inputObservation=await bounded(page.evaluate(()=>({events:window.__r146LongDateInputs,dropped:window.__r146LongDateInputDropped})),5000,'input log');if(c.inputObservation.events.some(x=>x.trusted)||c.inputObservation.dropped)throw Error('Unexpected trusted input or dropped input records');}catch(e){failed=true;issue(prefix+' input log',e);}}
    if(cdp){try{await bounded(cdp.send('Emulation.setCPUThrottlingRate',{rate:1}),5000,'CPU reset');c.cpuReset=true;}catch(e){failed=true;issue(prefix+' CPU reset',e);}}
    if(context){try{await bounded(context.close(),5000,'context close');c.contextClosed=true;}catch(e){failed=true;issue(prefix+' context close',e);}}
    c.completed=stamp();if(c.console.some(x=>x.type==='error')||c.pageErrors.length||c.requestFailures.length||c.httpErrors.length||c.blocked.length)issue(prefix+' recorded errors',Error('All console/page/request/HTTP errors retained, including favicon404'));save();
   }
   if(failed||!c.contextClosed||result.timedOut)throw Error('Stop before next context after incomplete/timeout/closure');
  }
  result.status='COMPLETE_GEOMETRY_FIXTURE_NOT_GAMEPLAY';
 }catch(e){issue('run',e);}
 finally{
  if(browser){try{await bounded(browser.close(),6000,'browser close');result.browserClosed=true;}catch(e){issue('browser close',e);}}if(watchdog)clearTimeout(watchdog);
  try{result.identityAfter=identity();result.sourceEnvironmentUnchanged=JSON.stringify(result.identityBefore)===JSON.stringify(result.identityAfter);if(!result.sourceEnvironmentUnchanged)throw Error('Source/environment changed');}catch(e){issue('post identity',e);}
  try{result.httpAfter=await httpGate();if(!result.httpAfter.matched)throw Error('Post HTTP mismatch');}catch(e){issue('post HTTP',e);}
  result.actualRows=result.contexts.reduce((n,c)=>n+c.modes.reduce((a,m)=>a+(m.rows||0),0),0);result.unknownOrUnreachedRows=result.expectedCases-result.contexts.reduce((n,c)=>n+c.modes.reduce((a,m)=>a+(m.validRows||0),0),0);
  result.complete=result.status==='COMPLETE_GEOMETRY_FIXTURE_NOT_GAMEPLAY'&&result.actualRows===result.expectedCases&&result.browserClosed&&result.sourceEnvironmentUnchanged===true&&result.httpAfter?.matched===true&&result.contexts.every(c=>c.contextClosed&&c.finalRestoration?.matches&&c.savedBytesUnchanged);
  result.allLayoutTargetsMeasured=result.complete&&result.contexts.every(c=>c.modes.every(m=>m.validRows===372&&m.otherUnknownRows===0));result.allRecordedIntersectionsClear=result.allLayoutTargetsMeasured&&result.contexts.every(c=>c.modes.every(m=>m.dateOverlapRows===0&&m.otherOverlapRows===0));
  result.exitCode=process.exitCode||0;result.completed=stamp();save();console.log(JSON.stringify({complete:result.complete,actualRows:result.actualRows,unknownOrUnreachedRows:result.unknownOrUnreachedRows,allLayoutTargetsMeasured:result.allLayoutTargetsMeasured,allRecordedIntersectionsClear:result.allRecordedIntersectionsClear,browserClosed:result.browserClosed,exitCode:result.exitCode}));
 }
})().catch(e=>{console.error(String(e.stack||e));process.exitCode=1;});
