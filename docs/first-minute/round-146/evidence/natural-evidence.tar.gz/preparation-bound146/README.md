# R146 米づくり365 844×390 — root実行待ち

準備のみ。ready=false、pendingRootServer/Parse/Gate=true。WTはroot作成の `/workspace/ricepia-firstminute-round146`、branch `codex/firstminute-round146`、HEAD `6334d3103bbfa20f8b92e744b369be2183af1abe`（root提供、当方Git未実行）。サーバー8000はまだWT145で別fixture待ち。今回のNode/parse/browser/HTTP/tests/Git/製品編集は0。入口はfrozenの4フラグが揃うまで、Playwright import・出力作成・browser起動より前に停止する。

## 3本の再利用範囲

元は `/workspace/scratch/first-minute/round-142/preparation/{run.cjs,helpers.cjs,strict-play.cjs}`。変更はR146のsource/output/HEAD/env名/説明・390×844→844×390、未ready入口guard1行だけ。入力選択、予約、120ms/100px/6move、2200ms相対待ち、ACK所有権、初期10秒とstrict60秒、4撮影、deadline/cleanup、CPU1・実音・実3D・外部遮断の処理は変えない。`binding-diff.patch`が3本の全差分、`binding-record.json`の逆置換とguard除去で原3本へbyte一致する。

[仮設計資料](../preparation-design/README.md)の自然手順と観察軸を引き継ぐ。仮資料のsourceRoot=null/WT未作成はその保存時点の記録で、現在の束縛は本ディレクトリのsource-manifestを使う。旧metadata/report/log/PNGはコピーしない。既存出力metadata.json/strictがある場合は入口が拒否し、取り直しや上書きをしない。

## 自然手順

fresh mobile/touch context、DPR1、CPU1、844×390、unmuted Chromium、本物のlocalthree r128/Field3D、実Date.now/performance時計。DOMContentLoaded後10秒は無入力で観察し、原observe-10s画像完了と初カードの既存可視/中心hit/音ON安全確認後にplayを始める。初入力はplay+250ms予約。方向は現在の明瞭な手本か同じ日付/問題/選択肢で過去に見えた明瞭な手本だけ。cue不明は未送信skip、誤答を作る逆入力や内部正解参照を入れない。状態・保存・seed・音・時計・描画の差替えなし。内部detailState.available/loader/音/3Dは受動診断だけで入力を選ばない。

初期観察画像とplay10/30/60秒画像の原4枚。要求/完了は別時刻で、締切の同一frameとはしない。controllerが残したrawをそのまま使い、rootが終了後に4PNGのSHAと実見範囲を記録する。後続入力をACK未確認で送らず、60秒以降は新入力せず、開始済み指のreleaseを別記する。DOM/rAF・fly受理・日付送り・○✗/理由・初肯定・次カード準備proxy・次の実swipe・heartbeat/longtaskを分ける。2200msはcontrollerの待ちで人の読了時間ではない。

## 固定と保護境界

source7はAGENTS/flow/Kome HTML/core3/vendor。R142 source7から変わったのはAGENTSだけ（06d6baa5…）、Kome本体5・flowは同一、保護3も同一。AGENTSの新規則「検査の完了段名に緑✓を0.8秒、案内/棒は次段へ、小✓は棒にも、字/音は足さない」を読了し記録した。Komeの0.3秒手本・速いswipe・tap非選択/非移動・初カード影・理由2秒/最初3枚持越し/避け配置・30秒カード・ほのぼの音/切替・太陽/かかしは変更しない。engine.js/field3d.js/cards.jsは編集禁止。

selected environment8はR142と同じ実ファイルSHA。HTTP5はindex/engine/field3d/cards/vendorのみで、全OSや全assetを保証しない。localhost/127.0.0.1のHTTP8000だけ通し、外部は遮断してエラー記録を残す。既知favicon404等も消さずactual exitへ反映する。既知PR1201/1205の札折返し・回答日付/理由折返しは新規発見へ数えない。提供本文の原則は仮設計資料の出典に従い、原動画未視聴・新規資料読了0のまま。

## rootのみの実行前後

1. R145 fixture完了/所有browser終了後に、server8000をWT146へ移す。実HEAD/branch/許容差分、serverプロセスと配信元、browser0をrootが確認する。同じKome bytesを出すWT145との違いはHTTP hashだけでは判別できないため、serverの所有/起動記録も要る。
2. source7/environment8の再hashとHTTP5、3コードの全差分を読む。`parse-plan.json`のとおりrun/helpersはCommonJS Function body、strict-playはAsyncFunction bodyとしてconstructだけし、require/import/eval/invokeはしない。parse actual exitを別記録する。
3. 対応する確認が終わってからfrozenの `ready=true`、`pendingRootServer=false`、`pendingRootParse=false`、`pendingRootGate=false` にする。コードとprepared filesは変えず、フラグ更新後のfrozen SHAとroot gateを保存する。実sourceが進んだらそのまま実行せず再bindする。
4. 下の単一runをrootだけが実行し、actual exit、source/env/HTTP前後、cpu reset、browser.closeと残存browserを記録する。成功/エラー/未到達を区別し、raw/4PNGを保存する。

```sh
R146_ROOT_HEAD=6334d3103bbfa20f8b92e744b369be2183af1abe timeout --signal=TERM --kill-after=5s 180s /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/scratch/first-minute/round-146/preparation-bound146/run.cjs
```

cwdはWT146。上のコマンドは未実行。root外側timeoutやclose失敗時にはdescendant browserも確認・整理し、次の実行へ重ねない。未readyではmetadata/strictも作らない。元R142 primaryのactual1や数値・原画像はR146の結果に転記しない。人の理解・疲れ・主体性・離脱率・実機の指/音/回線は未測定。
