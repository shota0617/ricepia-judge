(function () {
  const root = '/workspace/scratch/first-minute/round-146/preparation-bound146';
  const mono = () => Number(process.hrtime.bigint()) / 1e6;
  const cleanError = e => String(e && e.message || e);
  let run = null;

  function timedRead(r, kind, callback) {
    const entry = { id: r.reads.length + 1, kind, sentAt: mono(), sentEpoch: Date.now(), status: 'pending' };
    r.reads.push(entry);
    return page.evaluate(callback).then(value => {
      entry.receivedAt = mono(); entry.receivedEpoch = Date.now(); entry.status = 'resolved';
      entry.roundTripMs = entry.receivedAt - entry.sentAt;
      Object.assign(entry, value.readTiming);
      return value;
    }, error => {
      entry.receivedAt = mono(); entry.receivedEpoch = Date.now(); entry.status = 'rejected';
      entry.roundTripMs = entry.receivedAt - entry.sentAt; entry.error = cleanError(error);
      throw error;
    });
  }

  function bounded(promise, ms, label) {
    let timer;
    return Promise.race([promise, new Promise(resolve => {
      timer = setTimeout(() => resolve({ timedOut: label, timeoutMs: ms }), ms);
    })]).finally(() => clearTimeout(timer));
  }

  function shot(r, name, targetMs, phase) {
    const entry = { name, phase, targetMs, requestedAt: mono(), requestedEpoch: Date.now(), status: 'pending', file: path.join(r.out, name + '.png') };
    entry.requestedElapsedMs = entry.requestedAt - (phase === 'play' ? r.play.startedAt : r.observation.startedAt);
    r.screenshots.push(entry);
    const pending = cdp.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false }).then(result => {
      fs.writeFileSync(entry.file, Buffer.from(result.data, 'base64'));
      entry.status = 'saved'; entry.completedAt = mono(); entry.captureMs = entry.completedAt - entry.requestedAt;
      say({ screenshot: entry.file, phase, targetMs, requestedElapsedMs: entry.requestedElapsedMs, captureMs: entry.captureMs });
      return entry;
    }, e => { entry.status = 'error'; entry.error = cleanError(e); return entry; });
    r.pendingShots.push(pending);
    return pending;
  }

  async function collect(r) {
    const gestureCompletion = await bounded(Promise.allSettled([...r.pendingGestures,...r.pendingCleanup]), 15000, 'gesture cleanup/acknowledgements');
    const tracePromise = page.evaluate(() => {
      const t = window.__komeObservation;
      if (!t) return { error: 'observation trace is unavailable' };
      t.stop();
      return { timeOrigin: t.timeOrigin, environment: t.environment, installedAt: t.installedAt, playMarker: t.playMarker, stoppedAt: t.stoppedAt,
        events: t.events, ui: t.ui, cueHistory:t.cueHistory, cueHistoryDropped:t.cueHistoryDropped, paintOpportunities: t.paintOpportunities, longTasks: t.longTasks,
        longTaskRetention: { limit:t.longTaskLimit, observed:t.longTaskSeen, retained:t.longTasks.length, dropped:t.dropped.longTasks },
        heartbeats: t.heartbeats, rafGaps: t.rafGaps, sampling: t.sampling, longTaskObservation: t.longTaskObservation,
        threeResourceTiming: performance.getEntriesByType("resource").filter(e => /\/(field3d\.js|vendor\/three\.min\.js)(?:[?#]|$)/.test(e.name)).map(e => ({name:e.name,startTime:e.startTime,responseEnd:e.responseEnd,duration:e.duration})),
        dropped: t.dropped, initialVisibleUI: t.initialVisibleUI, finalVisibleUI: t.visibleUI(),
        initial3d: t.initial3d, final3d: window.Field3D && Field3D.debugInfo ? Field3D.debugInfo() : null };
    }).catch(e => ({ error: cleanError(e) }));
    const [trace, captures, inputs] = await Promise.all([
      bounded(tracePromise, 15000, 'browser trace collection'),
      bounded(Promise.allSettled(r.pendingShots), 15000, 'pending screenshots'),
      bounded(Promise.allSettled(r.pendingInputs), 15000, 'pending input acknowledgements')
    ]);
    const result = { viewport: r.viewport, observation: r.observation, play: r.play, screenshots: r.screenshots,
      gestures: r.gestures, skippedChoices:r.skippedChoices, skippedInputs: r.skippedInputs, lateCleanup: r.lateCleanup, firstReservation: r.firstReservation, earlyCard: r.earlyCard, reads: r.reads, nodeHeartbeats: r.nodeHeartbeats, nodeSampling: r.nodeSampling,
      events: trace, errors: r.errors, blocked: [...new Set(global.blocked || [])],
      collection: { gestureCompletion: gestureCompletion?.timedOut ? gestureCompletion : 'settled', screenshots: captures && captures.timedOut ? captures : 'settled', inputs: inputs && inputs.timedOut ? inputs : 'settled' },
      notes: ['Passive whyOn and paddyWord DOM fields do not inspect, patch or identify the private product timer. CSS visibility alone is not physical display.',
        'DOM mutations and next animation-frame callbacks do not prove physical display latency.',
        'R146 answer observations are passive only: fly is an acceptance proxy; visible mark/why is a DOM proxy; detailAvailable and card-center hit are readiness proxies, not a successful next swipe. Next actual gesture results are separately recorded. First positive feedback is not a long-task or readiness metric.',
        'Loader state2 means script loading was requested, not init or physical-render completion. Resource timing, initial/final real3D checks, longtask support/errors, rAF gaps and input ACKs are separate evidence.',
        'Screenshot request and completion times are recorded separately; a late capture is not an exact deadline frame.',
        'Only manually requested CDP gestures are sent; no internal game choice or advance function is called.',
        'Read timings separate Node send/receive from browser callback execution. Browser times use performance.timeOrigin plus performance.now().',
        'Heartbeat and rAF gap samples read date, card class, inline transform and the hand cue computed transform, opacity and visibility; they do not prove physical display or identify a long-task cause.',
        'Sampling stops when trace collection executes; use the Node play deadline to exclude later browser samples.',
        'The first swipe uses visible-card coordinates checked after the observation photograph was saved, then a Node reservation at actual play start plus250ms; no further browser read is inserted before sending.',
        'No new touch starts after60s. A touch already started is always ended, including separately logged late cleanup; exclude that cleanup from ordinary play input counts.',
        'Direction comes from the currently clear rendered hand cue, otherwise the latest clear cue on the same date/question/choice labels. Existing heartbeat/status reads collect cues; no phase-seeking retry or answer data is used. A card without a clear cue history skips that opportunity, separately from sent inputs.',
        'Cue visibility uses DOM geometry and computed styles, not physical display measurement. Added cue reads mean this is not a controlled latency comparison with R98.'] };
    fs.writeFileSync(path.join(r.out, 'report.json'), JSON.stringify(result, null, 2));
    for (const [event, handler] of r.listeners) page.off(event, handler);
    r.result = result;
    say({ stoppedAtMs: r.play.stoppedAt - r.play.startedAt, report: path.join(r.out, 'report.json'), gestures: r.gestures.length, screenshots: r.screenshots.map(x => ({ name: x.name, status: x.status })) });
    return result;
  }

  global.beginKomeObservation = async function (directory = root) {
    if (run && !run.result) throw new Error('The previous observation is still active. Finish it before beginning another.');
    fs.mkdirSync(directory, { recursive: true });
    const r = run = { out: directory, viewport: page.viewportSize(), observation: { startedAt: mono(), startedEpoch: Date.now(), navigationStartedEpoch: global.loaded || null },
      play: null, screenshots: [], pendingShots: [], gestures: [], pendingInputs: [], pendingGestures: [], pendingCleanup: [], skippedChoices: [], skippedInputs: [], lateCleanup: [], reads: [], nodeHeartbeats: [],
      nodeSampling: { intervalMs: 250, limit: 1000, dropped: 0, ticks: 0, maxGapMs: 0 },
      errors: (global.errors || []).map(e=>({phase:'before-instrumentation',...e})), listeners: [] };
    let nodeLast = mono();
    r.nodeHeartbeatTimer = setInterval(() => {
      const at = mono(), gapMs = at - nodeLast; nodeLast = at;
      r.nodeSampling.ticks++; r.nodeSampling.maxGapMs = Math.max(r.nodeSampling.maxGapMs, gapMs);
      if (r.nodeHeartbeats.length < r.nodeSampling.limit) r.nodeHeartbeats.push({ at, epoch: Date.now(), gapMs });
      else r.nodeSampling.dropped++;
    }, r.nodeSampling.intervalMs);
    r.observationShot = new Promise(resolve => { r.observationTimer = setTimeout(() => resolve(shot(r, 'observe-10s', 10000, 'observation')), 10000); });
    for (const [event, handler] of [
      ['pageerror', e => r.errors.push({ at: mono(), kind: 'pageerror', message: cleanError(e) })],
      ['console', m => { if (m.type() === 'error') r.errors.push({ at: mono(), kind: 'console', message: m.text() }); }],
      ['requestfailed', q => r.errors.push({ at: mono(), kind: 'requestfailed', url: q.url(), message: q.failure()?.errorText })]
    ]) { page.on(event, handler); r.listeners.push([event, handler]); }
    const sentAt = mono();
    const installed = await page.evaluate(() => {
      if (window.__komeObservation) window.__komeObservation.stop();
      const t = window.__komeObservation = { timeOrigin: performance.timeOrigin, installedAt: performance.now(), playMarker: null, stoppedAt: null,
        events: [], ui: [], paintOpportunities: [], longTasks: [], longTaskLimit: 1000, longTaskSeen: 0, heartbeats: [], rafGaps: [],
        sampling: { heartbeatIntervalMs: 250, heartbeatLimit: 1000, heartbeatTicks: 0, heartbeatMaxGapMs: 0,
          rafGapThresholdMs: 50, rafGapLimit: 1000, rafCallbacks: 0, rafMaxGapMs: 0 },
        dropped: { events: 0, ui: 0, heartbeats: 0, rafGaps: 0, longTasks: 0 }, active: true };
      t.environment={hardwareConcurrency:navigator.hardwareConcurrency,deviceMemory:navigator.deviceMemory,maxTouchPoints:navigator.maxTouchPoints,coarse:matchMedia('(pointer: coarse)').matches};
      const get = id => document.getElementById(id), text = id => get(id)?.textContent?.trim() || '';
      const lightState = () => ({ date: text('swBigDate'), cardClass: get('swCard')?.className || '', transform: get('swCard')?.style.transform || '', handCue:readHandCue(), answer:answerRead() });
      const visible = e => {
        if(!e)return false;
        const r=e.getBoundingClientRect();
        if(!r.width||!r.height||r.right<=0||r.bottom<=0||r.left>=innerWidth||r.top>=innerHeight)return false;
        for(let p=e;p;p=p.parentElement){const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)<=0)return false;}
        return true;
      };
      // Read-only diagnostics never participate in direction or input scheduling.
      function answerRead() {
        const card=get('swCard'),mark=get('swMark'),why=get('swWhy'),b=card?.getBoundingClientRect();
        const x=b?b.x+b.width/2:-1,y=b?b.y+b.height*.55:-1;
        const hit=x>=0&&x<innerWidth&&y>=0&&y<innerHeight?document.elementFromPoint(x,y):null;
        const mr=mark?.getBoundingClientRect(),ms=mark&&getComputedStyle(mark);
        let detailAvailable=null,detailError=null,loaderState=null,loaderError=null;
        try { if(window.__swipe?.detailState)detailAvailable=window.__swipe.detailState().available; } catch(e){detailError=String(e.message||e);}
        try { if(window.__k3d?.state)loaderState=window.__k3d.state(); } catch(e){loaderError=String(e.message||e);}
        return {fly:!!card?.classList.contains('fly'),cardVisible:visible(card),cardCenterOwnsPoint:!!card&&!!hit&&card.contains(hit),
          cardCenterHit:hit?{id:hit.id,tag:hit.tagName}:null,detailAvailable,detailError,
          markOn:!!mark?.classList.contains('on'),markVisible:visible(mark),markOpacity:ms?Number(ms.opacity):null,
          markRect:mr?{x:mr.x,y:mr.y,width:mr.width,height:mr.height}:null,
          whyVisible:visible(why),whyClass:why?.className||'',loaderState,loaderError,threeRevision:window.THREE?.REVISION||null};
      }
      t.cueHistory=[]; t.cueHistoryDropped=0;
      let rememberedCue=null;
      function readHandCue() {
        const at=performance.now(),card=get('swCard'),hand=get('swHand');
        const identity={date:text('swBigDate'),title:text('swTitle'),question:text('swText'),
          left:card?.querySelector('.eL .eLb')?.textContent?.trim()||'',right:card?.querySelector('.eR .eLb')?.textContent?.trim()||''};
        const cardKey=JSON.stringify(identity);
        if (rememberedCue?.cardKey!==cardKey) rememberedCue=null;
        const move=hand?.querySelector('.hdMove'),finger=hand?.querySelector('.hdFinger');
        const trailL=hand?.querySelector('.hdTrailL'),trailR=hand?.querySelector('.hdTrailR');
        const opacity=e=>e&&visible(e)?Number(getComputedStyle(e).opacity):0;
        let x=null,readError=null;
        try { if(move)x=new DOMMatrixReadOnly(getComputedStyle(move).transform).m41; }
        catch(error) { readError=String(error.message||error); }
        const fingerOpacity=opacity(finger),leftOpacity=opacity(trailL),rightOpacity=opacity(trailR);
        const cardVisible=visible(card),handVisible=visible(hand);
        const left=cardVisible&&handVisible&&fingerOpacity>=0.5&&Number.isFinite(x)&&x<=-8&&leftOpacity>=0.5&&rightOpacity<0.5;
        const right=cardVisible&&handVisible&&fingerOpacity>=0.5&&Number.isFinite(x)&&x>=8&&rightOpacity>=0.5&&leftOpacity<0.5;
        const currentSide=left?'left':right?'right':null;
        const observed={at,cardKey,identity,currentSide,x,fingerOpacity,leftOpacity,rightOpacity,cardVisible,handVisible,readError};
        if(currentSide) {
          rememberedCue={...observed,side:currentSide};
          if(t.cueHistory.length<1000)t.cueHistory.push(rememberedCue);else t.cueHistoryDropped++;
        }
        return {...observed,selected:rememberedCue,basis:currentSide?'current':rememberedCue?'same-card-memory':'no-visible-cue-on-current-card'};
      }
      function state() {
        const card = get('swCard'), wrap = get('swWrap');
        return { date: text('swBigDate'), title: text('swTitle'), left: card?.querySelector('.eL .eLb')?.textContent?.trim() || '', right: card?.querySelector('.eR .eLb')?.textContent?.trim() || '',
          cardClass: card?.className || '', transform: card?.style.transform || '', guide: !!wrap?.classList.contains('demoOn'), gameClass: get('sGame')?.className || '',
          markClass: get('swMark')?.className || '', trace: [...document.querySelectorAll('#swTrace [data-pixtrace]')].map(e => e.getAttribute('data-pixtrace')),
          whyOn: !!get('swWhy')?.classList.contains('on'), whyText: text('swWhy'),
          paddyWordText: text('swPdWord'), paddyWordClass: get('swPdWord')?.className || '',
          paddyWordVisibility: get('swPdWord') ? getComputedStyle(get('swPdWord')).visibility : null,
          paddyPop: !!document.querySelector('#swPaddy .pdPop.on'), idle: !!get('swIdle')?.hasAttribute('data-on'), count: text('swCount'), nextMile: text('swNextMile'), answer:answerRead() };
      }
      t.visibleUI = () => ({ ...state(), handCue:readHandCue(), elements: ['swCard','swHand','swBigDate','swTitle','swText','swEdge','swHint','swMark','swTrace','swPaddy','swCount','swNextMile','swStageTrack','swIdle','swWhy','swPdWord'].map(id => {
        const e=get(id),r=e?.getBoundingClientRect(); return { id, visible: visible(e), text: e?.textContent?.trim() || '', rect: r ? { x:r.x,y:r.y,width:r.width,height:r.height } : null };
      }) });
      t.initialVisibleUI = t.visibleUI();
      t.initial3d = window.Field3D && Field3D.debugInfo ? Field3D.debugInfo() : null;
      let heartbeatLast = performance.now(), rafLast = heartbeatLast, rafId = null;
      const heartbeatTimer = setInterval(() => {
        if (!t.active) return;
        const at = performance.now(), gapMs = at - heartbeatLast; heartbeatLast = at;
        t.sampling.heartbeatTicks++; t.sampling.heartbeatMaxGapMs = Math.max(t.sampling.heartbeatMaxGapMs, gapMs);
        if (t.heartbeats.length < t.sampling.heartbeatLimit) t.heartbeats.push({ at, gapMs, ...lightState() });
        else t.dropped.heartbeats++;
      }, t.sampling.heartbeatIntervalMs);
      const sampleFrame = frameAt => {
        if (!t.active) return;
        const at = performance.now(), gapMs = at - rafLast; rafLast = at;
        t.sampling.rafCallbacks++; t.sampling.rafMaxGapMs = Math.max(t.sampling.rafMaxGapMs, gapMs);
        if (gapMs >= t.sampling.rafGapThresholdMs) {
          if (t.rafGaps.length < t.sampling.rafGapLimit) t.rafGaps.push({ at, frameAt, gapMs, ...lightState() });
          else t.dropped.rafGaps++;
        }
        rafId = requestAnimationFrame(sampleFrame);
      };
      rafId = requestAnimationFrame(sampleFrame);
      let last = '', rafPending = false;
      function noteUI(reason) {
        if (!t.active) return;
        const s=state(),key=JSON.stringify(s); if (key===last) return; last=key;
        if (t.ui.length<2500) t.ui.push({ at:performance.now(),reason,...s }); else t.dropped.ui++;
        if (!rafPending) { rafPending=true; requestAnimationFrame(() => { rafPending=false; if(t.active)t.paintOpportunities.push({at:performance.now(),date:text('swBigDate'),transform:get('swCard')?.style.transform||'',answer:answerRead()}); }); }
      }
      const onEvent = e => { if (!t.active) return; const v={type:e.type,eventTimeStamp:e.timeStamp,handledAt:performance.now(),x:e.clientX,y:e.clientY,pointerId:e.pointerId,pointerType:e.pointerType??null,isPrimary:e.isPrimary,trusted:e.isTrusted,target:e.target?.id||e.target?.tagName}; if(t.events.length<2500)t.events.push(v);else t.dropped.events++; };
      const types=['pointerdown','pointermove','pointerup','pointercancel','click'];
      types.forEach(k=>document.addEventListener(k,onEvent,{capture:true,passive:true}));
      const observer=new MutationObserver(()=>noteUI('mutation'));
      ['swCard','swWrap','sGame','swMark','swTrace','swPaddy','swIdle','swBigDate','swTitle','swEdge','swCount','swNextMile','swWhy','swPdWord'].forEach(id=>{
        const e=get(id);if(e)observer.observe(e,{attributes:true,childList:true,characterData:true,subtree:!['sGame','swWrap'].includes(id),attributeFilter:['class','style','data-on','data-pixtrace']});
      });
      let longObserver=null;
      t.longTaskObservation={supported:typeof PerformanceObserver!=='undefined'&&(PerformanceObserver.supportedEntryTypes||[]).includes('longtask'),observing:false,error:null};
      try { longObserver=new PerformanceObserver(list=>{for(const e of list.getEntries()){if(!t.active)continue;t.longTaskSeen++;if(t.longTasks.length<t.longTaskLimit)t.longTasks.push({start:e.startTime,duration:e.duration});else t.dropped.longTasks++;}});longObserver.observe({type:'longtask',buffered:false});t.longTaskObservation.observing=true; } catch(e) {t.longTaskObservation.error=String(e.message||e);}
      t.stop=()=>{if(!t.active)return;t.stoppedAt=performance.now();t.active=false;clearInterval(heartbeatTimer);if(rafId!==null)cancelAnimationFrame(rafId);observer.disconnect();if(longObserver)longObserver.disconnect();types.forEach(k=>document.removeEventListener(k,onEvent,true));};
      noteUI('installed');
      return { browserNow:performance.now(),timeOrigin:performance.timeOrigin };
    });
    r.observation.clockSync={sentAt,ackAt:mono(),...installed};
    return { observationStartedAt:r.observation.startedAt, screenshot:path.join(directory,'observe-10s.png'), next:'await komeObservationShot(); then inspect screenshot and call startKomePlay()' };
  };

  function atNodeTime(at, callback) {
    const tick = () => { const left = at - mono(); if (left > 0) { setTimeout(tick, Math.max(1, left)); return; } callback(); };
    setTimeout(tick, Math.max(0, at - mono()));
  }

  global.prepareKomeFirstSwipe = async function () {
    const r = run;
    if (!r || r.play) throw new Error('Prepare the visible first card during observation.');
    const value = await bounded(timedRead(r, 'early-card', () => {
      const browserStartedAt = performance.now();
      const e = document.getElementById('swCard'), b = e?.getBoundingClientRect();
      let visible = !!b && b.width > 0 && b.height > 0;
      for (let p = e; p; p = p.parentElement) { const s = getComputedStyle(p); if (s.display === 'none' || s.visibility !== 'visible' || Number(s.opacity) <= 0) visible = false; }
      const x = b ? b.x + b.width / 2 : 0, y = b ? b.y + b.height * .55 : 0, hit = document.elementFromPoint(x,y);
      const result = { rect:b ? {x:b.x,y:b.y,width:b.width,height:b.height} : null, width:innerWidth, height:innerHeight,
        ui:window.__komeObservation?.visibleUI(), visible, point:{x,y}, cardOwnsPoint:!!e && !!hit && e.contains(hit),
        sound:window.__ks?.state?.(), storage:Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('kome365_')).map(k=>[k,localStorage.getItem(k)])) };
      result.readTiming = {browserStartedAt,browserEndedAt:performance.now(),timeOrigin:performance.timeOrigin};
      return result;
    }), 5000, 'early visible card');
    value.capturedAt = mono();
    value.direction=value.ui?.handCue?.selected?.side||null;
    value.pathValid=value.direction==='left'?value.point.x-100>=16:value.direction==='right'?value.point.x+100<=value.width-16:null;
    value.valid = !value.timedOut && value.visible && value.cardOwnsPoint && value.ui?.date === '1月1日' && value.sound?.on === true && (value.direction===null||value.pathValid) && value.point.y > 0 && value.point.y < value.height;
    r.earlyCard = value;
    return value;
  };

  global.reserveKomeFirstSwipe = function () {
    const r = run; if (!r || r.play || r.firstReservation) throw new Error('Reserve one first swipe during observation.');
    const info = r.firstReservation = { reservedAt:mono(), playScheduledAt:r.observation.startedAt+10000, touchScheduledAt:null, direction:null, durationMs:120 };
    let resolvePlay, resolveFirst;
    const play = new Promise(resolve=>{resolvePlay=resolve;});
    const first = new Promise(resolve=>{resolveFirst=resolve;});
    atNodeTime(info.playScheduledAt, async () => {
      try {
        info.observationPhoto = await bounded(r.observationShot, 15000, 'observation photograph');
        if (info.observationPhoto.status !== 'saved') throw new Error('Observation photograph was not saved; play and input omitted.');
        const firstCard = await prepareKomeFirstSwipe();
        info.direction=firstCard.direction;info.handCue=firstCard.ui?.handCue||null;
        if (!firstCard.valid) {
          info.invalidFirstCard = firstCard;
          throw new Error('VisibleJan1 card after the observation photograph failed the existing safety checks; play and input omitted.');
        }
        const started = startKomePlay();
        info.playStartedAt = started.playStartedAt;
        info.touchScheduledAt = started.playStartedAt + 250;
        resolvePlay({...started, firstCard});
        atNodeTime(info.touchScheduledAt, () => {
          info.touchTimerFiredAt = mono();
          if (!r.play || !r.earlyCard?.valid || r.earlyCard.capturedAt >= info.playStartedAt) {
            info.error = 'Post-photo visibleJan1 card was not valid before play start; reserved input omitted.';
            resolveFirst({error:info.error}); return;
          }
          info.coordinateAgeMs = mono() - r.earlyCard.capturedAt;
          if(!info.direction){const result=komeSkipChoice(info.handCue,'reserved-first');info.result=result;resolveFirst(result);return;}
          komeSwipe({direction:info.direction,durationMs:120,distancePx:100,prepared:r.earlyCard,cue:info.handCue}).then(result=>{info.result=result;resolveFirst(result);}, e=>{info.error=cleanError(e);resolveFirst({error:info.error});});
        });
      } catch (e) {
        clearInterval(r.nodeHeartbeatTimer);
        clearTimeout(r.observationTimer);
        info.setupFailedAt = mono();
        info.observationPhoto = info.observationPhoto || r.screenshots.find(s=>s.name==='observe-10s') || null;
        info.playError = cleanError(e);
        resolvePlay({error:info.playError});
        resolveFirst({error:info.playError});
      }
    });
    return {play,first,info};
  };

  global.komeWaitForInput = async function () {
    const r=run; if (!r?.activeGesture?.completion) return {settled:true};
    return bounded(r.activeGesture.completion.then(()=>({settled:true})),15000,'pending gesture');
  };

  global.komeObservationShot = () => { if(!run)throw new Error('Begin observation first.');return run.observationShot; };
  global.komeSkipChoice = (cue,phase,reason='no-visible-cue-on-current-card') => {
    const row={skipped:true,phase,reason,at:mono(),cue};run.skippedChoices.push(row);return row;
  };
  global.komeStatus = async () => timedRead(run, 'status', () => {
    const browserStartedAt = performance.now();
    const value = { at: performance.now(), ui: window.__komeObservation?.visibleUI() };
    value.readTiming = { browserStartedAt, browserEndedAt: performance.now(), timeOrigin: performance.timeOrigin };
    return value;
  });

  global.startKomePlay = function () {
    const r=run;if(!r||r.play)throw new Error('Begin one observation, then start play once.');
    if(mono()-r.observation.startedAt<10000)throw new Error('The initial ten-second observation is not finished.');
    r.play={startedAt:mono(),startedEpoch:Date.now(),durationMs:60000,stoppedAt:null};
    r.play.observationToPlayMs=r.play.startedAt-r.observation.startedAt;
    r.markerPromise=page.evaluate(()=>{const t=window.__komeObservation;if(t)t.playMarker=performance.now();return t?.playMarker;}).then(at=>{r.play.browserMarkerAt=at;},e=>{r.play.markerError=cleanError(e);});
    r.ended = new Promise(resolve=>{r.resolveEnd=resolve;});
    [10000,30000].forEach(ms=>setTimeout(()=>{shot(r,'play-'+ms/1000+'s',ms,'play');},ms));
    setTimeout(()=>{
      r.play.stoppedAt=mono();r.play.stoppedEpoch=Date.now();
      clearInterval(r.nodeHeartbeatTimer);
      if (r.activeGesture?.finishTouch) r.activeGesture.finishTouch('play-deadline');
      shot(r,'play-60s',60000,'play');
      say({playStopped:true,elapsedMs:r.play.stoppedAt-r.play.startedAt});
      r.finalizing=collect(r);r.finalizing.then(r.resolveEnd,e=>r.resolveEnd({error:cleanError(e)}));
    },60000);
    return {playStartedAt:r.play.startedAt,stopAfterMs:60000,next:'Choose a visible action, then await komeSwipe({direction:"left"}) or direction:"right".'};
  };

  global.komeSwipe = async function ({direction,durationMs=120,distancePx=100,x,y,steps=6,prepared=null,cue=null}={}) {
    const r=run;if(!r?.play||r.play.stoppedAt)throw new Error('No active sixty-second play window.');
    if(r.activeGesture)throw new Error('The previous gesture still has pending input acknowledgements; inspect its result before sending another.');
    if(!['left','right'].includes(direction))throw new Error('Choose left or right from the visible card.');
    if(!Number.isFinite(durationMs)||durationMs<40||durationMs>1200||!Number.isInteger(steps)||steps<2||steps>12)throw new Error('Use a duration40–1200ms and2–12 steps.');
    let visible = prepared;
    if (!visible) visible=await bounded(timedRead(r, 'visible-card', () => {
      const browserStartedAt = performance.now();
      const e=document.getElementById('swCard'),r=e?.getBoundingClientRect();
      const value = {rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null,width:innerWidth,ui:window.__komeObservation?.visibleUI()};
      value.readTiming = { browserStartedAt, browserEndedAt: performance.now(), timeOrigin: performance.timeOrigin };
      return value;
    }),5000,'visible card read');
    if(visible.timedOut)throw new Error('Visible card read exceeded5000ms; no gesture was sent.');
    if(cue&&(!cue.selected||cue.selected.side!==direction||cue.cardKey!==visible.ui?.handCue?.cardKey))return komeSkipChoice(cue,'before-touch','cue-card-or-direction-changed');
    const b=visible.rect;if(!b||!b.width||!b.height)throw new Error('The card is not visible.');
    x=x??b.x+b.width/2;y=y??b.y+b.height*.55;
    if(x<b.x||x>b.x+b.width||y<b.y||y>b.y+b.height)throw new Error('Start within the visible card.');
    const endX=Math.max(16,Math.min(visible.width-16,x+(direction==='left'?-1:1)*distancePx));
    if(mono()+durationMs>=r.play.startedAt+60000)throw new Error('Not enough time remains for this gesture; the play window ends at60s.');
    const g={id:r.gestures.length+1,direction,durationMs,intendedDistancePx:endX-x,startedAt:mono(),uiBefore:visible.ui,cue,usedPreparedCard:!!prepared,preparedAt:prepared?.capturedAt||null,sends:[]};r.gestures.push(g);r.activeGesture=g;
    const commands=[];
    let touchStarted = false, touchEnded = false;
    function send(type,px,py,scheduledMs,reason='scheduled'){
      const attemptedAt = mono(), late = attemptedAt >= r.play.startedAt + 60000;
      if ((type === 'touchStart' && late) || (type === 'touchMove' && (late || !touchStarted || touchEnded)) || (type === 'touchEnd' && (!touchStarted || touchEnded))) {
        r.skippedInputs.push({ gestureId: g.id, type, scheduledMs, attemptedAt, reason: late ? 'play deadline reached; no new input sent' : 'touch absent or already ended; no input sent' });
        return Promise.resolve();
      }
      if (type === 'touchStart') touchStarted = true;
      if (type === 'touchEnd') touchEnded = true;
      const m={type,scheduledMs,sentAt:attemptedAt,sentEpoch:Date.now(),x:px,y:py,reason};m.actualOffsetMs=m.sentAt-g.startedAt;
      if (type === 'touchEnd' && late) { m.lateCleanup = true; m.gestureId = g.id; r.lateCleanup.push(m); }
      g.sends.push(m);
      const p=cdp.send('Input.dispatchTouchEvent',{type,timestamp:m.sentEpoch/1000,touchPoints:type==='touchEnd'?[]:[{x:px,y:py,id:1}]}).then(()=>{m.ackAt=mono();m.ackDelayMs=m.ackAt-m.sentAt;},e=>{m.ackAt=mono();m.error=cleanError(e);});
      r.pendingInputs.push(p);return p;
    }
    g.finishTouch = reason => {
      if (!touchStarted || touchEnded) return Promise.resolve();
      const promise = send('touchEnd',endX,y,durationMs,reason);
      commands.push(promise); r.pendingCleanup.push(promise); return promise;
    };
    commands.push(send('touchStart',x,y,0));
    for(let i=1;i<=steps;i++){
      const ms=durationMs*i/(steps+1),px=x+(endX-x)*i/steps;
      commands.push(new Promise(resolve=>setTimeout(()=>resolve(send('touchMove',px,y,ms)),ms)));
    }
    commands.push(new Promise(resolve=>setTimeout(()=>resolve(send('touchEnd',endX,y,durationMs)),durationMs)));
    const acknowledged=Promise.allSettled(commands).then(()=>{g.acknowledgedAt=mono();g.roundTripMs=g.acknowledgedAt-g.startedAt;r.activeGesture=null;});
    Object.defineProperty(g,'completion',{value:acknowledged}); r.pendingGestures.push(acknowledged);
    const waited=await bounded(acknowledged,Math.max(5000,durationMs+2000),'gesture acknowledgements');
    if(waited?.timedOut)g.ackWaitTimedOut=true;
    return {id:g.id,roundTripMs:g.roundTripMs,pending:!!r.activeGesture,sendOffsetsMs:g.sends.map(m=>m.actualOffsetMs),ackDelaysMs:g.sends.map(m=>m.ackDelayMs),errors:g.sends.filter(m=>m.error)};
  };

  global.finishKomeRun = async function () {
    if(!run?.play)throw new Error('Start the play window first.');
    const result=await run.ended;
    if(result.error)return result;
    return {report:path.join(run.out,'report.json'),elapsedMs:run.play.stoppedAt-run.play.startedAt,gestures:run.gestures.length,
      screenshots:run.screenshots.map(s=>({name:s.name,status:s.status,file:s.file,captureMs:s.captureMs})),
      eventCount:result.events.events?.length||0,uiChanges:result.events.ui?.length||0,errors:result.errors,collection:result.collection};
  };
  return {installed:['beginKomeObservation','prepareKomeFirstSwipe','reserveKomeFirstSwipe','komeWaitForInput','komeObservationShot','komeSkipChoice','komeStatus','startKomePlay','komeSwipe','finishKomeRun'],directory:root};
})()
