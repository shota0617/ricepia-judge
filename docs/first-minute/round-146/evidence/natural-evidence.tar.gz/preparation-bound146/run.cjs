const fs=require('fs'),path=require('path'),crypto=require('crypto');
const readiness=JSON.parse(fs.readFileSync(path.join(__dirname,'frozen.json'),'utf8'));if(readiness.ready!==true||readiness.pendingRootServer!==false||readiness.pendingRootParse!==false||readiness.pendingRootGate!==false)throw Error('R146 preparation is pending root server/parse/final gate; no output or browser is opened.');
const requireLocal=require('module').createRequire('/workspace/ricepia-judge/tools/playtest.js');
const {chromium}=requireLocal('playwright');
const root=__dirname,source='/workspace/ricepia-firstminute-round146',origin='http://localhost:8000';
const expectedSourceCommit='6334d3103bbfa20f8b92e744b369be2183af1abe',expectedHtmlSha256='1131aca205f44acd47243b6769d2c68acf0526128eb4bf7ab0e7a242b50f5f62';
const expectedSourceHashes={"kome365/index.html":"1131aca205f44acd47243b6769d2c68acf0526128eb4bf7ab0e7a242b50f5f62","kome365/engine.js":"c3d0cef6bb108d5b6d8fe38aaf0c08fe7994bdab08bf92775865a6e0222469a3","kome365/field3d.js":"a5c1dad91d5c0c326f1394fad9c5d04e7e3b8d13e3a2b8b1757c7aa08d3558ff","kome365/cards.js":"b15c5b2f56ef9c0c8361fa2fa6a039085919ca516b4a2e6e5a1b3bb691dde744","kome365/vendor/three.min.js":"9274bbcec8d96168626c732b5d31c775aa8cfb7eaa0599bec0c175908a2c1ce2"};
const stamp=()=>({nodeEpochMs:Date.now(),nodeMonotonicMs:Number(process.hrtime.bigint())/1e6});
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const sourceManifest=JSON.parse(fs.readFileSync(path.join(root,'source-manifest.json'),'utf8'));
const environmentManifest=JSON.parse(fs.readFileSync(path.join(root,'environment-manifest.json'),'utf8'));
const identityPins=()=>{const values={source:{},environment:{}};for(const [name,expected]of Object.entries(sourceManifest.source)){values.source[name]=hash(fs.readFileSync(path.join(source,name)));if(values.source[name]!==expected)throw Error('Source7 mismatch: '+name);}for(const [file,expected]of Object.entries(environmentManifest.hashes)){values.environment[file]=hash(fs.readFileSync(file));if(values.environment[file]!==expected)throw Error('Environment8 mismatch: '+file);}return values;};
const sourceHashes=()=>Object.fromEntries(['kome365/index.html','kome365/engine.js','kome365/field3d.js','kome365/cards.js','kome365/vendor/three.min.js'].map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]));
const save=(name,x)=>fs.writeFileSync(path.join(root,name),JSON.stringify(x,null,2)+'\n');
const bounded=(promise,ms,label)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(label+' exceeded '+ms+'ms')),ms);})]).finally(()=>clearTimeout(timer));};
(async()=>{
 const metadata={source,origin,sourceCommit:process.env.R146_ROOT_HEAD||null,sourceHashes:sourceHashes(),codeHashes:Object.fromEntries(['run.cjs','helpers.cjs','strict-play.cjs'].map(n=>[n,hash(fs.readFileSync(path.join(root,n)))])),viewport:{width:844,height:390},isMobile:true,hasTouch:true,launch:{headless:true,ignoreDefaultArgs:['--mute-audio'],args:['--no-sandbox','--disable-background-networking','--disable-component-update','--disable-sync','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost']},startedAt:new Date().toISOString(),browserOpened:false,browserClosed:false,requestedCpuRate:1,runIssues:[],conditions:["R146 new844x390 primary on root-selected6334d310. R138 natural120ms/100px/6move visible-cue/current-card-memory controller retained. No fixed10, fixture, profiler, keyword answer choice, state/clock/audio/3D replacement. Added answer/readiness/mark/longtask-support observations never select inputs. External159/SwiftShader report and previous R138 results are not this run.","Ten real seconds without input; await original observation PNG and safe current-card read, then60 real seconds. First input reservation+250ms, later2200ms relative waits, original4 screenshots, ACK/deadline/cleanup retained.","Root runs only after R146 parse/server/source/browser gates. Root asserts actual HEAD via R146_ROOT_HEAD; rebind if main moves. Source7/environment8 and HTTP5 gated before/after; selected files only, not all assets/OS. First positive, acceptance, date progression, DOM-visible mark, readiness proxy, real next input and long tasks are separate observations."]};
 metadata.sourceVerification={expectedHead:expectedSourceCommit,expectedHtmlSha256,expectedSourceHashes,servedURL:origin+'/kome365/index.html',verified:false,scope:'Root-supplied HEAD assertion; source7/environment8 and selected local/HTTP5 hashes before/after. Other served assets are not hash-gated.'};
 if(fs.existsSync(path.join(root,'metadata.json'))||fs.existsSync(path.join(root,'strict')))throw Error('Preserve prior attempt: metadata/strict output already exists.');
 save('metadata.json',metadata);
 let ownBrowser,cpuSession,cpuAttempted=false;
 const issue=(stage,error)=>{metadata.runIssues.push({stage,at:stamp(),error:String(error.stack||error)});process.exitCode=1;};
 const cpuCommand=async(rate,record)=>{record.requested=stamp();record.rate=rate;try{await bounded(cpuSession.send('Emulation.setCPUThrottlingRate',{rate}),10000,'CPU'+rate+' acknowledgement');record.acknowledged=stamp();record.ok=true;}catch(error){record.ok=false;record.error=String(error.stack||error);throw error;}};
 try{
  const frozen=JSON.parse(fs.readFileSync(path.join(root,'frozen.json'),'utf8'));
  for(const [name,row]of Object.entries(frozen.files))if(hash(fs.readFileSync(path.join(root,name)))!==row.sha256)throw Error('Prepared bytes changed: '+name);
  metadata.identityBefore=identityPins();
  const verification=metadata.sourceVerification;
  verification.startedAt=Date.now();
  verification.localHead=metadata.sourceCommit;
  verification.localHtmlSha256=metadata.sourceHashes['kome365/index.html'];
  if(verification.localHead!==expectedSourceCommit||Object.entries(expectedSourceHashes).some(([name,sha])=>metadata.sourceHashes[name]!==sha))throw Error('Bound R146 root HEAD assertion or one of five protected/source hashes differs; no browser opened.');
  verification.served={};
  for(const [name,sha]of Object.entries(expectedSourceHashes)){const row=verification.served[name]={url:origin+'/'+name,requested:stamp()};const response=await fetch(row.url,{redirect:'error',signal:AbortSignal.timeout(10000)});row.httpStatus=response.status;row.sha256=hash(Buffer.from(await response.arrayBuffer()));row.completed=stamp();if(row.httpStatus!==200||row.sha256!==sha)throw Error('Local served source mismatch: '+name+' HTTP'+row.httpStatus+'; no browser opened.');}
  verification.httpStatus=verification.served['kome365/index.html'].httpStatus;verification.servedHtmlSha256=verification.served['kome365/index.html'].sha256;
  verification.verified=true;verification.completedAt=Date.now();
  save('metadata.json',metadata);
  ownBrowser=await chromium.launch({executablePath:'/usr/bin/chromium',...metadata.launch});metadata.browserOpened=true;
  const environmentSession=await ownBrowser.newBrowserCDPSession();
  try{metadata.actualBrowserArguments=(await bounded(environmentSession.send('Browser.getBrowserCommandLine'),10000,'Actual browser arguments')).arguments;metadata.actualUnmuted=Array.isArray(metadata.actualBrowserArguments)&&!metadata.actualBrowserArguments.some(a=>/^--mute-audio(?:=|$)/.test(a));if(!metadata.actualUnmuted)throw Error('Actual unmuted browser condition not confirmed');}finally{if(metadata.actualUnmuted!==true)await environmentSession.detach();}
  try{const values=await bounded(Promise.allSettled([environmentSession.send('Browser.getVersion'),environmentSession.send('SystemInfo.getInfo')]),5000,'Browser environment metadata');metadata.browserEnvironment={version:values[0].status==='fulfilled'?values[0].value:{error:String(values[0].reason)},systemInfo:values[1].status==='fulfilled'?values[1].value:{error:String(values[1].reason)}};}catch(error){metadata.browserEnvironmentError=String(error.message||error);}finally{await environmentSession.detach();}
  global.browser=ownBrowser;global.fs=fs;global.path=path;global.wait=ms=>new Promise(r=>setTimeout(r,ms));global.say=x=>console.log(JSON.stringify(x));
  global.open=async(relative,viewport)=>{
   if(global.ctx)await global.ctx.close();
   global.ctx=await ownBrowser.newContext({viewport,isMobile:true,hasTouch:true,deviceScaleFactor:1,serviceWorkers:'block'});
   global.errors=[];global.blocked=[];
   await ctx.route('**/*',route=>{const u=new URL(route.request().url());if(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)&&u.port==='8000')return route.continue();blocked.push(u.href);return route.abort('blockedbyclient');});
   global.page=await ctx.newPage();
   page.on('pageerror',e=>errors.push({at:Date.now(),kind:'pageerror',message:String(e.stack||e)}));
   page.on('console',m=>{if(m.type()==='error')errors.push({at:Date.now(),kind:'console',message:m.text()});});
   global.cdp=await ctx.newCDPSession(page);cpuSession=global.cdp;cpuAttempted=true;metadata.cpuSetup={};await cpuCommand(1,metadata.cpuSetup);
   metadata.navigation={url:origin+relative,waitUntil:'domcontentloaded',requested:stamp()};global.loaded=Date.now();metadata.cpu1AcknowledgedBeforeNavigation=metadata.cpuSetup.ok&&metadata.cpuSetup.acknowledged.nodeMonotonicMs<=metadata.navigation.requested.nodeMonotonicMs;
   const response=await page.goto(origin+relative,{waitUntil:'domcontentloaded',timeout:20000});metadata.navigation.acknowledged=stamp();metadata.navigation.httpStatus=response?.status();metadata.navigation.finalURL=page.url();if(response?.status()!==200||page.url()!==origin+relative)throw Error('Navigation status or final local URL mismatch');
  };
  eval(fs.readFileSync(path.join(root,'helpers.cjs'),'utf8'));
  const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
  metadata.result=await new AsyncFunction(fs.readFileSync(path.join(root,'strict-play.cjs'),'utf8'))();
  const extra=await bounded(page.evaluate(()=>({resources404:performance.getEntriesByType('resource').filter(e=>e.responseStatus===404).map(e=>({name:e.name,status:e.responseStatus})),sound:window.__ks?.state?.(),field3d:window.Field3D?.debugInfo?.(),threeRevision:window.THREE?.REVISION,storage:Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('kome365_')).map(k=>[k,localStorage.getItem(k)])),date:document.getElementById('swBigDate')?.textContent})),15000,'Final metadata read');
  save('strict/extra.json',extra);
  if(extra.threeRevision!=='128'||!extra.field3d?.active)metadata.resourceError='Real localthree128/Field3D was not confirmed active';
  if(extra.sound?.on!==true)metadata.audioError='Application audioON not confirmed';
  if(metadata.resourceError)issue('real-3d',Error(metadata.resourceError));if(metadata.audioError)issue('application-audio',Error(metadata.audioError));
  if(metadata.result?.error)issue('play-result',Error(metadata.result.error));
  if(metadata.result?.errors?.length)issue('observed-errors',Error(JSON.stringify(metadata.result.errors)));
  if(metadata.result?.collection&&Object.values(metadata.result.collection).some(v=>v!=='settled'))issue('incomplete-collection',Error(JSON.stringify(metadata.result.collection)));
  const reportFile=path.join(root,'strict/report.json');if(fs.existsSync(reportFile)){const report=JSON.parse(fs.readFileSync(reportFile,'utf8'));if(report.events?.error||report.events?.timedOut)issue('trace-collection',Error(JSON.stringify(report.events)));if(report.gestures?.some(g=>g.sends.some(s=>s.error)))issue('input-acknowledgement',Error('One or more CDP input commands rejected; raw sends retained'));if(report.screenshots?.some(s=>s.status!=='saved'))issue('screenshots',Error('One or more screenshots not saved; raw timing/status retained'));}
  const driverFile=path.join(root,'strict/driver-timing.json');if(fs.existsSync(driverFile)){const driver=JSON.parse(fs.readFileSync(driverFile,'utf8'));if(driver.errors?.length)issue('driver-errors',Error(JSON.stringify(driver.errors)));}
 }catch(error){metadata.error=String(error.stack||error);console.error(metadata.error);issue('run',error);}
 finally{
  if(cpuAttempted&&cpuSession){metadata.cpuReset={};try{await cpuCommand(1,metadata.cpuReset);}catch(error){issue('cpu-reset',error);}}
  if(ownBrowser){metadata.browserClose={requested:stamp()};try{await ownBrowser.close();metadata.browserClosed=true;metadata.browserClose.acknowledged=stamp();}catch(error){metadata.closeError=String(error.stack||error);issue('browser-close',error);}}
  try{metadata.headAfter=process.env.R146_ROOT_HEAD||null;metadata.sourceHashesAfter=sourceHashes();metadata.sourceUnchanged=metadata.headAfter===metadata.sourceCommit&&JSON.stringify(metadata.sourceHashes)===JSON.stringify(metadata.sourceHashesAfter);if(!metadata.sourceUnchanged)issue('source-postcheck',Error('Root HEAD assertion or five hashes changed'));metadata.identityAfter=identityPins();metadata.httpAfter={};for(const [name,sha]of Object.entries(expectedSourceHashes)){const response=await fetch(origin+'/'+name,{redirect:'error',signal:AbortSignal.timeout(10000)});const row=metadata.httpAfter[name]={status:response.status,sha256:hash(Buffer.from(await response.arrayBuffer()))};if(row.status!==200||row.sha256!==sha)throw Error('After HTTP mismatch: '+name);}}catch(error){issue('source-postcheck',error);}
  metadata.completedAt=new Date().toISOString();metadata.requestedExitCode=process.exitCode||0;save('metadata.json',metadata);console.log(JSON.stringify({browserClosed:metadata.browserClosed,sourceUnchanged:metadata.sourceUnchanged,cpuReset:metadata.cpuReset?.ok,error:metadata.error,runIssues:metadata.runIssues,exitCode:metadata.requestedExitCode}));
 }
})().catch(error=>{console.error(String(error.stack||error));process.exitCode=1;});
