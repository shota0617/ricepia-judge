await open('/kome365/index.html', { width: 844, height: 390 });
const observation = await beginKomeObservation('/workspace/scratch/first-minute/round-146/preparation-bound146/strict');
const monotonic = () => Number(process.hrtime.bigint()) / 1e6;
const driver = { observationStartedAt: observation.observationStartedAt, waits: [], choices: [], errors: [] };
const reserved = reserveKomeFirstSwipe();
const started = await reserved.play;
driver.firstReservation = reserved.info;
if (started.error) {
  driver.errors.push({at:monotonic(),kind:'pre-play-setup',message:started.error});
  driver.completedAt = monotonic();
  fs.writeFileSync('/workspace/scratch/first-minute/round-146/preparation-bound146/strict/driver-timing.json',JSON.stringify(driver,null,2));
  throw Error(started.error);
}
driver.earlyCard = started.firstCard;
driver.playStartedAt = started.playStartedAt;
const elapsed = () => monotonic() - started.playStartedAt;
let i = 0;
try {
  const first = await reserved.first;
  driver.firstReservation = reserved.info;
  if (first.error) throw Error(first.error);
  const initial = driver.earlyCard?.ui;
  const firstDirection=driver.firstReservation.direction;
  driver.choices.push({choice:1,date:initial?.date,title:initial?.title,direction:firstDirection,visibleLabel:firstDirection?initial?.[firstDirection]:null,handCue:driver.firstReservation.handCue,reserved:true,result:first});
  i = 1;
  if (first.pending) { const settled = await komeWaitForInput(); if (settled.timedOut) throw Error('First input acknowledgements remain pending; no later input sent.'); }
  while (elapsed() < 59000) {
    const entry = { beforeChoice:i+1,requestedMs:2200,startedAt:monotonic() };
    driver.waits.push(entry); await wait(2200); entry.completedAt=monotonic();entry.actualMs=entry.completedAt-entry.startedAt;
    if (elapsed() >= 58000) break;
    const before = await komeStatus();
    if (elapsed() >= 58000) break;
    const handCue=before.ui.handCue,direction=handCue?.selected?.side||null;
    const choice = {choice:i+1,date:before.ui.date,title:before.ui.title,direction,visibleLabel:direction?before.ui[direction]:null,handCue,sayStartedAt:monotonic()};
    driver.choices.push(choice);say(choice);choice.sayCompletedAt=monotonic();
    const result=direction?await komeSwipe({direction,durationMs:120,cue:handCue}):komeSkipChoice(handCue,'later-choice');
    choice.result=result;
    choice.resultSayStartedAt=monotonic();say(result);choice.resultSayCompletedAt=monotonic();i++;
    if (result.pending) { const settled=await komeWaitForInput();if(settled.timedOut)throw Error('Input acknowledgements remain pending; no later input sent.'); }
  }
} catch (error) { driver.errors.push({at:monotonic(),message:String(error.stack||error)}); }
const result = await finishKomeRun();
driver.completedAt=monotonic();driver.opportunities=i;driver.gesturesReturned=driver.choices.filter(c=>c.result?.id!=null).length;driver.skippedChoices=driver.choices.filter(c=>c.result?.skipped).length;
fs.writeFileSync('/workspace/scratch/first-minute/round-146/preparation-bound146/strict/driver-timing.json',JSON.stringify(driver,null,2));
return result;
