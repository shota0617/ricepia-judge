# R146 A1・5サイズ初期表示（未実行）

before/after共通runner。320×568、390×844、568×320、844×390、820×1180の順で、各normal (`no-preference`)→`reduce`、計10 fresh contextsを1 browser内で直列観察する。通常primary、reduce pilot、入力再現10回、特殊保存状態fixtureは別母数。本runnerは入力APIを呼ばず、初期の自然な状態を変更しない。

実HTML/local8000、mobile/touch/DPR1、CPU1、実時計・描画・音ミュートなし。source7/env8/HTTP5をbatch両端で照合し、同一batch内では製品を変更しない。before-bindingは既存repeatと同byte。after-bindingは未作成で開始前拒否し、rootが修正後のexact HTML SHA/実HEAD/rootReviewedAfterBinding=trueを別ファイルに束縛する。他6source、特にengine/field3d/cardsは固定。新テストをrunnerのpin対象へ加えない。

各contextはDCL後、fonts loaded・実1月1日/元日の田んぼ/左右の文・choices空・demoOn・実motion設定を受動待機する。成立したときだけ実10秒観察し、診断→原PNG→診断を保存する。待機上限で未成立なら10秒実施とは数えず、取得できる原PNG/診断はUNKNOWNとして保持。自然の保存/seedを注入せず、3DやAudioContextが操作前からactiveであることを要求しない。

pilotのdiagnoseに `#swPdWord` と読み取り専用choicesだけを追加。カード/矢印/左右札/日付/題/田の状態語/⌂/音ボタンの実rect、全文文字Range、祖先opacity/clip、centerhit/insideを保存する。矢印非表示のnormalもそのまま記録し、矢印表示を強制しない。Range交差はpaint遮蔽の確定ではなく、pointer-events:none矢印はhit stackに出ない場合がある。中心点が当たることは実際に指で押せたことではない。原PNG実見を別途行う。

UIready/初期診断/観察開始終了/写真取得開始終了/前後診断は別時点。normalの札・指などのアニメーションframeとreduceが同じとは主張しない。初期・写真前後の本文とchoicesが同じかを記録する。状態が変わった、カードが不可視、viewport/pref違いはUNKNOWN。全10枚の観測取得と、重なりのない見やすい表示は別判定。

passive listenerは全イベントとtrusted/時刻/対象/欠測を記録。trusted入力または欠測は停止。非trusted自動開始clickは全件残し起源未確定として分離し、自然入力成功に数えない。state/save/seed/DOM/CSS/時計/rAF/音やゲームhandlerの置換はない。

favicon404もconsole/page/request/HTTP全記録に残す。console/HTTPエラーだけで予定caseを抜き取らず、全体cleanExecution=false/exit1へ反映する。pageerror・request失敗・外部要求・watchdog・CPU reset/閉鎖不明などの技術失敗は残りNOTRUN、再試行/置換なし。各caseでCPU reset/context close、最後にbrowser close。観測成立とclean終了を分ける。

rootのみparse/gate・実行。未使用direct-child run-Nだけ許可し、原primary/pilot/repeatを上書きしない。

```sh
R146_REDUCE_LAYOUT_ROOT=1 R146_ROOT_HEAD=6334d3103bbfa20f8b92e744b369be2183af1abe R146_BINDING_SHA=<before-binding.jsonのSHA> timeout --signal=TERM --kill-after=2s 330s node /workspace/scratch/first-minute/round-146/reduce-cue-layout-prep/run.cjs before run-01
```

case40秒・batch300秒watchdogはbrowser.closeを要求する。外側timeoutや親終了は detached子孫の閉鎖証明ではない。rootが実exit・所有PID/live0/配信元を別receiptで確認してから次runtimeへ進む。準備者のNode/browser/parse/test/Git/HTTP実行0、製品・既存テスト変更0。
