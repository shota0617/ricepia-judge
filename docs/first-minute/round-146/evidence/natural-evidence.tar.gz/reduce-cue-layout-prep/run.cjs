// Root-only initial layout observation. Ten fresh contexts; no input commands.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),root=__dirname;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const stamp=()=>({epochMs:Date.now(),monotonicMs:Number(process.hrtime.bigint())/1e6});
const bounded=(p,ms,label)=>{let t;return Promise.race([p,new Promise((_,reject)=>{
  t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]).finally(()=>clearTimeout(t));};
const phase=process.argv[2],output=path.resolve(root,process.argv[3]||'');
if(!['before','after'].includes(phase)||path.dirname(output)!==root||
   !/^run-[0-9]+$/.test(path.basename(output))||fs.existsSync(output))throw Error('New direct-child run-N output required.');
const bindingFile=path.join(root,phase+'-binding.json');
if(!fs.existsSync(bindingFile))throw Error('Reviewed '+phase+' source binding is absent.');
const bytes=fs.readFileSync(bindingFile),binding=JSON.parse(bytes);
const baseline=JSON.parse(fs.readFileSync(path.join(root,'source-manifest.json')));
const environment=JSON.parse(fs.readFileSync(path.join(root,'environment-manifest.json')));
const frozen=JSON.parse(fs.readFileSync(path.join(root,'frozen.json')));
if(process.env.R146_REDUCE_LAYOUT_ROOT!=='1'||process.env.R146_ROOT_HEAD!==binding.expectedHead||
   process.env.R146_BINDING_SHA!==hash(bytes))throw Error('Root review, exact HEAD and binding SHA required before output/browser.');
if(binding.phase!==phase||binding.sourceRoot!==baseline.sourceRoot||
   Object.keys(binding.source).sort().join('|')!==Object.keys(baseline.source).sort().join('|')||
   Object.entries(baseline.source).some(([n,h])=>n!=='kome365/index.html'&&binding.source[n]!==h))
  throw Error('Only exact index.html bytes may differ in after binding.');
if(phase==='after'&&binding.rootReviewedAfterBinding!==true)throw Error('After binding lacks root review.');
for(const[n,r]of Object.entries(frozen.files))if(hash(fs.readFileSync(path.join(root,n)))!==r.sha256)
  throw Error('Prepared bytes changed: '+n);
const diagnose=require('./diagnose.cjs');
const write=(file,data)=>fs.writeFileSync(file,JSON.stringify(data,null,2)+'\n');
async function gate(){
  const identity={source:{},environment:{}};
  for(const[n,h]of Object.entries(binding.source)){
    identity.source[n]=hash(fs.readFileSync(path.join(binding.sourceRoot,n)));
    if(identity.source[n]!==h)throw Error('Source mismatch: '+n);
  }
  for(const[n,h]of Object.entries(environment.hashes)){
    identity.environment[n]=hash(fs.readFileSync(n));
    if(identity.environment[n]!==h)throw Error('Environment mismatch: '+n);
  }
  const http=await Promise.all(baseline.httpFiles.map(async n=>{
    const r=await fetch('http://localhost:8000/'+n,{redirect:'error',signal:AbortSignal.timeout(10000)});
    const sha256=hash(Buffer.from(await r.arrayBuffer()));
    if(r.status!==200||sha256!==binding.source[n])throw Error('HTTP mismatch: '+n);
    return {name:n,status:r.status,sha256};
  }));return {at:stamp(),identity,http};
}
const textIdentity=d=>JSON.stringify([d.date,d.title,d.choices,
  ...['#swEdge .eL .eLb','#swEdge .eR .eLb'].map(s=>d.elements.find(e=>e.selector===s)?.text)]);
async function observe(browser,plan){
  const dir=path.join(output,'case-'+String(plan.index).padStart(2,'0'));fs.mkdirSync(dir);
  const r={...plan,started:stamp(),status:'UNKNOWN',inputCommands:0,errors:[],pageErrors:[],
    consoleErrors:[],requestFailures:[],httpErrors:[],blocked:[],contextClosed:false};
  const save=()=>write(path.join(dir,'case.json'),r);let context,page,cdp,watchdog;save();
  try{
    context=await browser.newContext({viewport:plan.viewport,isMobile:true,hasTouch:true,
      deviceScaleFactor:1,serviceWorkers:'block',reducedMotion:plan.motion});
    watchdog=setTimeout(()=>{r.errors.push({stage:'watchdog',message:'40s case deadline'});
      save();browser.close().catch(()=>{});},40000);
    await context.route('**/*',route=>{
      const u=new URL(route.request().url());
      if(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)&&u.port==='8000')return route.continue();
      r.blocked.push({at:stamp(),url:u.href});return route.abort('blockedbyclient');
    });
    await context.addInitScript(()=>{
      window.__r146LayoutInputs={events:[],dropped:0};
      for(const type of ['pointerdown','pointermove','pointerup','pointercancel','touchstart',
        'touchmove','touchend','touchcancel','click','keydown','keyup','wheel'])
        addEventListener(type,e=>{const q=window.__r146LayoutInputs;
          if(q.events.length>=1000){q.dropped++;return;}
          q.events.push({type,isTrusted:e.isTrusted,at:performance.now(),eventTimeStamp:e.timeStamp,
            target:{tag:e.target?.tagName??null,id:e.target?.id??null},pointerId:e.pointerId??null});
        },{capture:true,passive:true});
    });
    page=await context.newPage();
    page.on('pageerror',e=>r.pageErrors.push({at:stamp(),message:String(e.stack||e)}));
    page.on('console',m=>{if(m.type()==='error')r.consoleErrors.push({at:stamp(),text:m.text(),location:m.location()});});
    page.on('requestfailed',q=>r.requestFailures.push({at:stamp(),url:q.url(),failure:q.failure()}));
    page.on('response',q=>{if(q.status()>=400)r.httpErrors.push({at:stamp(),url:q.url(),status:q.status()});});
    cdp=await context.newCDPSession(page);await bounded(cdp.send('Emulation.setCPUThrottlingRate',{rate:1}),5000,'CPU1');
    r.cpuSetup={rate:1,acknowledged:stamp()};
    r.navigation={url:'http://localhost:8000/kome365/index.html',started:stamp()};
    const response=await page.goto(r.navigation.url,{waitUntil:'domcontentloaded',timeout:20000});
    r.navigation.completed=stamp();r.navigation.status=response?.status();r.navigation.finalURL=page.url();
    if(response?.status()!==200||page.url()!==r.navigation.url)throw Error('Unexpected navigation');
    r.readiness={started:stamp(),met:false};
    try{
      await page.waitForFunction(m=>window.__swipe&&document.fonts.status==='loaded'&&
        document.querySelector('#swCard')?.offsetWidth>0&&
        document.querySelector('#swBigDate')?.textContent==='1月1日'&&
        document.querySelector('#swTitle')?.textContent==='元日の田んぼ'&&
        document.querySelector('#swEdge .eL .eLb')?.textContent==='畦から田見る'&&
        document.querySelector('#swEdge .eR .eLb')?.textContent==='田へ行かない'&&
        document.querySelector('#swWrap')?.classList.contains('demoOn')&&
        window.__swipe.choices()===''&&matchMedia('(prefers-reduced-motion: reduce)').matches===(m==='reduce'),
        plan.motion,{timeout:10000});r.readiness.met=true;
    }catch(e){if(e.name==='TimeoutError')r.readiness.unknownReason=String(e);else throw e;}
    r.readiness.completed=stamp();r.initial=await bounded(page.evaluate(diagnose),10000,'initial diagnosis');
    r.observation={started:stamp(),requestedMs:10000,performed:r.readiness.met};
    if(r.readiness.met)await new Promise(resolve=>setTimeout(resolve,10000));
    r.observation.completed=stamp();r.observation.elapsedMs=r.observation.completed.monotonicMs-r.observation.started.monotonicMs;
    r.beforePhoto=await bounded(page.evaluate(diagnose),10000,'before photo');
    r.photo={file:'observe-10s.png',requested:stamp()};
    await bounded(page.screenshot({path:path.join(dir,r.photo.file),timeout:10000}),11000,'original PNG');
    r.photo.completed=stamp();r.photo.sha256=hash(fs.readFileSync(path.join(dir,r.photo.file)));
    r.afterPhoto=await bounded(page.evaluate(diagnose),10000,'after photo');
    r.inputObservation=await bounded(page.evaluate(()=>window.__r146LayoutInputs),5000,'input receipt');
    r.trustedInputs=r.inputObservation.events.filter(e=>e.isTrusted).length;
    r.syntheticEvents=r.inputObservation.events.filter(e=>!e.isTrusted);
    r.syntheticOrigin=r.syntheticEvents.length?'UNDETERMINED_RAW_RETAINED':'NONE_RECORDED';
    if(r.trustedInputs||r.inputObservation.dropped)throw Error('Trusted input or missing observations');
    const adequate=d=>d.viewport.width===plan.viewport.width&&d.viewport.height===plan.viewport.height&&
      d.reducedMotion===(plan.motion==='reduce')&&d.date==='1月1日'&&d.choices===''&&
      d.elements.find(e=>e.selector==='#swCard')?.visibleProxy===true;
    r.sameText=textIdentity(r.initial)===textIdentity(r.beforePhoto)&&textIdentity(r.beforePhoto)===textIdentity(r.afterPhoto);
    r.status=r.readiness.met&&adequate(r.beforePhoto)&&adequate(r.afterPhoto)&&r.sameText?'OBSERVED_NOT_A_LAYOUT_PASS':'UNKNOWN';
  }catch(e){r.errors.push({stage:'case',at:stamp(),message:String(e.stack||e)});}
  finally{
    if(cdp){try{await bounded(cdp.send('Emulation.setCPUThrottlingRate',{rate:1}),5000,'CPU reset');
      r.cpuReset={rate:1,ok:true,acknowledged:stamp()};}catch(e){r.errors.push({stage:'CPU reset',message:String(e)});}}
    if(context){try{await bounded(context.close(),5000,'context close');r.contextClosed=true;}
      catch(e){r.errors.push({stage:'context close',message:String(e)});}}
    if(watchdog)clearTimeout(watchdog);
    r.recordedErrors=r.errors.length+r.pageErrors.length+r.consoleErrors.length+r.requestFailures.length+r.httpErrors.length+r.blocked.length;
    r.safeToContinue=r.contextClosed&&r.cpuReset?.ok===true&&r.errors.length===0&&r.pageErrors.length===0&&r.requestFailures.length===0&&r.blocked.length===0;
    r.observationCaptured=r.status==='OBSERVED_NOT_A_LAYOUT_PASS'&&r.safeToContinue;
    r.completed=stamp();save();
  }return r;
}
(async()=>{
  fs.mkdirSync(output);const views=[[320,568],[390,844],[568,320],[844,390],[820,1180]];
  const planned=views.flatMap(([width,height],i)=>['no-preference','reduce'].map((motion,j)=>
    ({index:2*i+j+1,viewport:{width,height},motion})));
  const report={phase,binding,bindingSHA256:hash(bytes),started:stamp(),planned,cases:[],errors:[],browserClosed:false};
  const save=()=>write(path.join(output,'report.json'),report);let browser,watchdog;save();
  try{
    report.gateBefore=await gate();
    const {chromium}=require('module').createRequire('/workspace/ricepia-judge/tools/playtest.js')('playwright');
    browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,ignoreDefaultArgs:['--mute-audio'],
      args:['--no-sandbox','--disable-background-networking','--disable-component-update','--disable-sync',
        '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost']});report.browserVersion=browser.version();
    watchdog=setTimeout(()=>{report.errors.push({stage:'batch-watchdog',message:'300s browser close requested'});
      save();browser.close().catch(()=>{});},300000);
    const bc=await browser.newBrowserCDPSession();try{
      report.actualArguments=(await bounded(bc.send('Browser.getBrowserCommandLine'),5000,'actual arguments')).arguments;
      report.actualUnmuted=!report.actualArguments.some(a=>/^--mute-audio(?:=|$)/.test(a));
      if(!report.actualUnmuted)throw Error('Actual unmuted condition missing');
    }finally{await bc.detach();}
    for(const plan of planned){const r=await observe(browser,plan);
      report.cases.push({...plan,file:'case-'+String(plan.index).padStart(2,'0')+'/case.json',status:r.status,
        observationCaptured:r.observationCaptured,safeToContinue:r.safeToContinue,recordedErrors:r.recordedErrors});save();
      if(!r.safeToContinue)break;
    }
  }catch(e){report.errors.push({stage:'batch',at:stamp(),message:String(e.stack||e)});}
  finally{
    for(const p of planned.slice(report.cases.length))report.cases.push({...p,status:'NOTRUN',reason:'Previous operational failure; no replacement.'});
    if(browser){try{await bounded(browser.close(),10000,'browser close');report.browserClosed=true;}
      catch(e){report.errors.push({stage:'browser close',message:String(e)});}}
    if(watchdog)clearTimeout(watchdog);
    try{report.gateAfter=await gate();report.gatesUnchanged=JSON.stringify(report.gateBefore.identity)===JSON.stringify(report.gateAfter.identity);}
      catch(e){report.errors.push({stage:'post-gate',message:String(e)});}
    report.executedContexts=report.cases.filter(c=>c.status!=='NOTRUN').length;
    report.observations=report.cases.filter(c=>c.observationCaptured).length;
    report.observationsComplete=report.observations===10&&report.browserClosed&&report.gatesUnchanged===true;
    report.cleanExecution=report.errors.length===0&&report.cases.every(c=>c.recordedErrors===0)&&report.browserClosed&&report.gatesUnchanged===true;
    report.exitCode=report.observationsComplete&&report.cleanExecution?0:1;process.exitCode=report.exitCode;
    report.completed=stamp();save();console.log(JSON.stringify({observations:report.observations,cleanExecution:report.cleanExecution,browserClosed:report.browserClosed,exitCode:report.exitCode}));
  }
})().catch(e=>{console.error(String(e.stack||e));process.exitCode=1;});
