# R146 A1: 動きを減らす設定での初期矢印

未実行の最小pilot。通常primaryの8操作とは別母数。正規BrowserContext `reducedMotion:'reduce'`、fresh mobile 844×390、DCL後の受動初期診断が終わってから実時計10秒間入力なしで待ち、診断→原PNG→診断を保存する。DOMContentLoadedからの経過はnavigation/diagnosisの時刻で区別する。初日付・題名・左右札が自然に変われば保持し、写真前後の同本文条件が崩れればUNKNOWN。対象を強制表示しない。

入力API呼出し0。capture listenerは対象・時刻・trustedを保存するだけでゲーム処理を止めない。trusted入力0を要求し、syntheticがあれば全件記録・起源未確定のまま残す。syntheticを操作したことにせず、欠測も0件扱いにしない。初期3Dや音声contextの状態をそのまま記録し、操作前のactive/runningを強制・合格要件にしない。起動引数は音のミュートを外し、実引数でも確認する。

状態・save・seed・時計・DOM・CSS・描画・音の代替なし。正規pref以外は通常primaryと同じ製品/source7・environment8・HTTP5、実CPU1、localhost:8000のみ許可。別contextで旧保存を注入しない。protected engine/field3d/cardsを変更しない。原primaryとこの準備以外のファイルを上書きしない。

矢印両側、左右札と全文1文字Range、日付・題名・why/mark・指・上部ボタンの実rect/computed style/祖先clip/opacity/centerhitを受動採取する。矢印はpointer-events:noneなのでhit-testに出ないことがあり、centerhitは描画遮蔽の判定ではない。文字rectとの幾何重複をそのまま保存し、見える重なりは原PNGを実見して判定する。PNGは取得開始/終了時刻を持ち、前後診断と同一フレームとは呼ばない。字が隠れなければ変更しない。

`run.cjs` のgate/launch/closure方針は `/workspace/scratch/first-minute/round-146/preparation-bound146/run.cjs` を参照したが、controller/helpers/操作60秒は流用せず、新規の無入力観察に縮小した。source/environment manifestは原primaryと同byte。通常primary、過去実行出力、PNGをコピーしていない。

rootのみ実行。準備者・独立レビューはNode/parse/browser/HTTP/test/Gitを実行しない。rootは事前parse、実HEAD、serverのWT146束縛、他browserなし、最終prepared SHAを確認後、次の固定引数で新規出力へ1回だけ実行する。

```sh
R146_REDUCE_PILOT_ROOT=1 R146_ROOT_HEAD=6334d3103bbfa20f8b92e744b369be2183af1abe timeout --signal=TERM --kill-after=2s 75s node /workspace/scratch/first-minute/round-146/reduce-cue-pilot-prep/run.cjs run-01
```

新規direct-child `run-N` だけ許可。prepared SHA一致、source7/env8/HTTP5を両端確認。CPU reset・context/browser closeはfinally、browser起動後55秒watchdog。外側timeoutがbrowser子孫まで確実に整理する保証はないため、終了後はrootがlive process0を別途確認し、未確認なら次を起動しない。タイムアウト時に写真や終了記録が不足すればそのまま不足扱いとし、取り直して置換しない。

favicon404を含むconsole/page/request/HTTPエラーを保存し、エラーありは非0終了。`observationCaptured` は原画像・診断・入力・両端gate・閉鎖が揃ったこと、`cleanExecution` は記録エラー0を別々に示す。404で画像を消さず、観測成立を製品合格へ言い換えない。rootは事後に誤表示の有無を画像から評価する。
