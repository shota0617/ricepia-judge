# R146 reduce cue: 入力前10回と入力維持の共通手順

未実行の準備。正常motion primary・reduce pilot1回とは別母数。before/after同一コードで、1 browser内にfresh mobile contextを順に10個作り、各contextを閉じてから次へ進む。contextの保存/cacheを注入しない。GPU等のbrowser内部は共有されるので、10 cold browser/10独立利用者とは呼ばない。viewport844×390、正規reducedMotion reduce、実時計、CPU1、音ミュートなし、localhost:8000以外遮断を固定する。

各回はDCL後の受動初期診断から10秒無入力→診断→原PNG1枚→診断。元pilotのdiagnose.cjsを同byte使用し、両矢印と札の全文Range・祖先clip・rect・centerhitを保存する。両矢印可視、カード可視、写真前後の本文同一、trusted入力0を最低条件とする。矢印非表示や対象不足はUNKNOWNで保存し、0重複の合格にしない。重なりは入力前の独立欄に記録し、文字rect交差を「全文読めない文字数」へ言い換えない。原PNGの実見が別途必要。

続いて実カード中心付近(y55%)から左100px、6 moveのCDP touchを1回だけ送る。各点がviewport内かつカード配下hitを所有し、直前の本文が写真と一致する時だけ送る。hold120ms/600msを交互に各5回、明示した再現操作であり自然な手本選択ではない。指速度は入力前の矢印重なりの原因として扱わない。入力以外にstate/seed/save/時計/DOM/CSS/音/描画/正解を変更しない。

8 commandsをNode実時計で予定し、ACKを待って次の指時刻を決めない。各send/ACK、native event timestamp/handler時刻/座標/pointerId、100msとDOM変化時の状態を保存する。coalesced move数は6とは限らない。actual送信holdとnativeイベントhold、handler間隔は別値。touchEnd送信から8秒まで待ち、最後の診断/収集が遅れた実時刻も保存する。日付更新はnative pointerup eventTimeStampから8秒以内の原状態記録で判定し、最終日付だけで遅い成功を合格にしない。正常なdown/up各1、同pointerId、cancel0、ACK全8件を別条件とする。観測終端がcutoffへ届かなければ無反応確定にせずcoverage不足を残す。

runtimeの採取は受動listener/MutationObserver/100ms timerだけ。renderer負荷への観測影響はあり得るため、これで実機速度・離脱改善は測らない。初期3D/audio contextは自然な未開始を許容し、入力後に実状態を記録する。force active等はしない。非trustedの自動clickは原記録・起源未確定として分離。初期trusted入力は実行条件違反。

favicon404も全console/page/request/HTTPログに残し、エラーがあれば全体exit1。console/HTTPエラーによる非0と、写真・入力観測の有無は別々に保持する。console/HTTPログを理由に都合のよいcaseだけ除外・やり直ししない。入力送信失敗、timeout、pageerror、request失敗、外部遮断、source gate不一致、CPU reset/閉鎖未確認は次を起動せず、残りNOTRUN。対象不足/日付未進行のUNKNOWNは全件保持し、技術条件が成立する限り予定順で続ける。

source7/env8/HTTP5を各case前後とbatch前後で照合。protected engine/field3d/cards不変。before-bindingは準備に固定。after-binding.jsonはまだ存在せずafter実行を拒否する。rootの修正後に、他6sourceを同一に保ったindex.htmlのexact SHA・実HEAD・rootReviewedAfterBinding=trueを別ファイルへ束縛し独立レビューする。新testはこの表示runnerのpin対象へ勝手に追加しない。rootは指定bindingのSHAを環境変数で供給する。

rootのみ実行。Node/parse/browser/test/HTTP/Gitを準備者は実行していない。rootのparse・HEAD・server・source・live0確認後、次の引数で一度だけ実行する（BINDING_SHAは該当JSONの実SHA）。

```sh
R146_REDUCE_REPEAT_ROOT=1 R146_ROOT_HEAD=6334d3103bbfa20f8b92e744b369be2183af1abe R146_BINDING_SHA=BINDING_SHA timeout --signal=TERM --kill-after=2s 345s node /workspace/scratch/first-minute/round-146/reduce-cue-repeat-prep/run.cjs before run-01
```

出力は未使用direct-child run-Nのみ。原pilot/primary/既存結果はコピーしない。caseの40秒watchdog、batchの320秒watchdogはbrowser.closeを要求する。finallyでCPU reset/context close、batchでbrowser closeと最終gate。外側timeoutだけでは子孫browserを確実に整理できないため、rootは終了後のlive0を別receiptに残し、未確認なら次runtimeを始めない。全試行・UNKNOWN・NOTRUN・エラーを保存し、入力前10回と入力後10操作を別集計する。
