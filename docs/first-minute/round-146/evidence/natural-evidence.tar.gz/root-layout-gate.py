from pathlib import Path
import datetime, hashlib, json, subprocess, urllib.request, sys

PREP = Path('/workspace/scratch/first-minute/round-146/reduce-cue-layout-prep')
phase = sys.argv[1]
assert phase in ('before', 'after')
binding_path = PREP / (phase + '-binding.json')
binding = json.loads(binding_path.read_text())
root = Path(binding['sourceRoot'])
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'phase': phase, 'bindingSHA256': sha(binding_path), 'checks': {}}
for name, expected in binding['source'].items():
    actual = sha(root / name)
    report['checks'][name] = actual
    assert actual == expected, name
env = json.loads((PREP / 'environment-manifest.json').read_text())['hashes']
assert all(sha(p) == expected for p, expected in env.items())
frozen = json.loads((PREP / 'frozen.json').read_text())
assert all(sha(PREP / p) == row['sha256'] for p, row in frozen['files'].items())
report['environment8'] = True
report['prepared8'] = True
report['head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert report['head'] == binding['expectedHead']
report['status'] = subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True)
report['http'] = {}
for name in json.loads((PREP / 'source-manifest.json').read_text())['httpFiles']:
    with urllib.request.urlopen('http://localhost:8000/' + name, timeout=10) as response:
        h = hashlib.sha256(response.read()).hexdigest()
        assert response.status == 200 and h == binding['source'][name], name
        report['http'][name] = {'status': response.status, 'sha256': h}
server = Path('/proc/227012')
assert server.stat().st_uid == 1000
assert server.joinpath('stat').read_text().split()[21] == '5468082'
assert server.joinpath('cmdline').read_bytes() == b'python3\x00-m\x00http.server\x008000\x00'
report['serverIdentity'] = {'pid': 227012, 'startTicks': '5468082', 'argv': 'python3 -m http.server 8000'}
rows = subprocess.check_output(['ps', '-eo', 'pid,stat,comm'], text=True).splitlines()[1:]
report['liveBrowsers'] = [r.strip() for r in rows if (v := r.split()) and v[2] == 'chromium' and not v[1].startswith('Z')]
assert report['liveBrowsers'] == [], report['liveBrowsers']
report['parse'] = json.loads((PREP / 'root-parse.json').read_text())
assert report['parse']['actualExit'] == 0
report['independentReviewSHA256'] = sha(PREP.parent / 'reduce-cue-layout-review/review.json')
assert json.loads((PREP.parent / 'reduce-cue-layout-review/review.json').read_text())['blocking'] == 0
report['rootRead'] = ['run.cjs full', 'README.md full', 'diagnose.cjs prior full read, unchanged']
(PREP / ('root-' + phase + '-gate.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': True, 'phase': phase, 'head': report['head'], 'status': report['status'], 'liveBrowsers': report['liveBrowsers']}))
